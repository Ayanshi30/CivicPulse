import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "db.json");

// Initialize Google Gemini SDK
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY environment variable is missing. AI processing will fallback to rule-based mock responses.");
}

// Ensure database file exists with initial mock data
function initDatabase() {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      JSON.parse(data); // Validate JSON format
      return;
    } catch (e) {
      console.error("Malformed db.json, re-initializing...", e);
    }
  }

  const initialIssues = [
    {
      issue_id: "701a5b82-58cf-4828-912a-38827fa6c282",
      timestamp: new Date(Date.now() - 3 * 3600000).toISOString(),
      source: "sensor",
      issue_type: "damaged bridge",
      priority: "CRITICAL",
      location: { lat: 40.7152, lng: -74.0158, address: "West Crossing Bridge, Grid 4A", ward: "Ward 4" },
      description: "Sensor STRUCT-701 detected critical strain vectors and vibrational frequencies exceeding 4.2Hz on the main expansion joint.",
      evidence: ["Sensor reading: Structural strain ratio 1.45 (Normal max: 1.0)", "Consecutive anomalies: 12"],
      credibility_score: 10,
      affected_population_estimate: 1200,
      recommended_action: "Close left lane of West Crossing Bridge immediately; dispatch structural engineers for live stress testing.",
      assigned_department: "Public Works",
      resolution_sla_hours: 2,
      duplicate_of: null,
      civic_points_awarded: 30,
      map_marker: { color: "#EF4444", icon: "AlertOctagon", tooltip: "STRUCT-701: Bridge Strain Alert (CRITICAL)" },
      predictive_flag: false,
      escalation_required: true,
      status: "Assigned",
      verifications_count: 5,
      verified_by: ["system_admin"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 3 * 3600000).toISOString(), note: "Hardware IoT Sensor alert raised." },
        { status: "Verified", timestamp: new Date(Date.now() - 2.5 * 3600000).toISOString(), note: "Auto-verified by secondary stress-strain sensor cluster." },
        { status: "Assigned", timestamp: new Date(Date.now() - 2 * 3600000).toISOString(), note: "Assigned to Public Works Structural Emergency Team." }
      ],
      eta_days: 1,
      repair_cost_estimate: 45000
    },
    {
      issue_id: "cbe38b9e-647d-4177-ad54-8c8868df32f8",
      timestamp: new Date(Date.now() - 12 * 3600000).toISOString(),
      source: "citizen",
      issue_type: "missing manhole cover",
      priority: "CRITICAL",
      location: { lat: 40.7118, lng: -74.0042, address: "84 Oak St (Near intersection with 4th Ave)", ward: "Ward 4" },
      description: "A manhole cover is completely missing on the active bicycle lane. Highly dangerous, especially at night or in rainy weather.",
      evidence: ["Citizen image: https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=400&q=80"],
      credibility_score: 9,
      affected_population_estimate: 600,
      recommended_action: "Dispatch instant response team to place safety barriers and install a replacement heavy-duty cast iron manhole cover.",
      assigned_department: "Safety",
      resolution_sla_hours: 2,
      duplicate_of: null,
      civic_points_awarded: 20,
      map_marker: { color: "#EF4444", icon: "TriangleAlert", tooltip: "Citizen Alert: Missing Manhole Cover on Bike Lane" },
      predictive_flag: false,
      escalation_required: false,
      status: "In Progress",
      verifications_count: 4,
      verified_by: ["verifier_bob", "user_alice"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 12 * 3600000).toISOString(), note: "Reported by citizen with photo evidence." },
        { status: "Verified", timestamp: new Date(Date.now() - 11.5 * 3600000).toISOString(), note: "Community verification threshold achieved (3+ verifications)." },
        { status: "Assigned", timestamp: new Date(Date.now() - 11 * 3600000).toISOString(), note: "Assigned to Emergency Safety Crew." },
        { status: "In Progress", timestamp: new Date(Date.now() - 10 * 3600000).toISOString(), note: "Crew has set up barriers. Awaiting cover arrival." }
      ],
      eta_days: 0.2,
      repair_cost_estimate: 450
    },
    {
      issue_id: "492aef31-31bc-4019-9f79-beffc6109312",
      timestamp: new Date(Date.now() - 24 * 3600000).toISOString(),
      source: "sensor",
      issue_type: "streetlight outage",
      priority: "HIGH",
      location: { lat: 40.7185, lng: -74.0091, address: "Pine Ave Commercial Corridor", ward: "Ward 4" },
      description: "Sensor PHOTO-109 reported photometric illuminance reading of 0.15 lux (Threshold threshold: < 2.0 lux) for 3 consecutive hours during active operational schedule.",
      evidence: ["Sensor photo-reading: 0.15 lux", "Unit ID: PINE-LGT-89"],
      credibility_score: 10,
      affected_population_estimate: 350,
      recommended_action: "Schedule streetlight bulb and ballast replacement within 24 hours to restore nighttime corridor safety.",
      assigned_department: "Energy",
      resolution_sla_hours: 24,
      duplicate_of: null,
      civic_points_awarded: 10,
      map_marker: { color: "#F97316", icon: "LightbulbOff", tooltip: "PHOTO-109: Streetlight Corridor Outage (HIGH)" },
      predictive_flag: false,
      escalation_required: false,
      status: "Assigned",
      verifications_count: 1,
      verified_by: ["system_admin"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 24 * 3600000).toISOString(), note: "Photometric sensor alert raised." },
        { status: "Assigned", timestamp: new Date(Date.now() - 18 * 3600000).toISOString(), note: "Assigned to Municipal Grid Maintenance." }
      ],
      eta_days: 1,
      repair_cost_estimate: 150
    },
    {
      issue_id: "3a928ba1-827d-419b-a010-bb2a4fa365bf",
      timestamp: new Date(Date.now() - 48 * 3600000).toISOString(),
      source: "citizen",
      issue_type: "flooding",
      priority: "HIGH",
      location: { lat: 40.7095, lng: -74.0112, address: "Low-lying intersection on South St", ward: "Ward 4" },
      description: "Heavy pooling of water over 10cm depth blockading pedestrian crosswalks and clogging the storm gutters. Looks like a blocked drain.",
      evidence: ["Citizen note: Drainage completely blocked with leaves and litter."],
      credibility_score: 7,
      affected_population_estimate: 220,
      recommended_action: "Deploy hydro-vac truck to clear debris blockage from storm drain intake grate and check pipe flow capacity.",
      assigned_department: "Water & Sanitation",
      resolution_sla_hours: 24,
      duplicate_of: null,
      civic_points_awarded: 15,
      map_marker: { color: "#F97316", icon: "Droplets", tooltip: "Citizen Alert: Local Flooding / Blocked Drain" },
      predictive_flag: false,
      escalation_required: false,
      status: "In Progress",
      verifications_count: 3,
      verified_by: ["user_alice", "verifier_bob", "citizen_clara"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 48 * 3600000).toISOString(), note: "Citizen reported via platform web app." },
        { status: "Verified", timestamp: new Date(Date.now() - 44 * 3600000).toISOString(), note: "Verified by 3 independent neighborhood validators." },
        { status: "Assigned", timestamp: new Date(Date.now() - 40 * 3600000).toISOString(), note: "Assigned to Sewer and Drainage Department." },
        { status: "In Progress", timestamp: new Date(Date.now() - 12 * 3600000).toISOString(), note: "Crews on-site pumping out standing water." }
      ],
      eta_days: 0.5,
      repair_cost_estimate: 1200
    },
    {
      issue_id: "e492cfda-1b91-4c12-9213-9a38ef8bfcf0",
      timestamp: new Date(Date.now() - 72 * 3600000).toISOString(),
      source: "citizen",
      issue_type: "overflowing bin",
      priority: "MEDIUM",
      location: { lat: 40.7102, lng: -74.0018, address: "Metro Plaza Main Pavilion", ward: "Ward 4" },
      description: "Standard public waste container is completely overflowing with food packaging and plastic bottles. Litter starting to spread across the plaza.",
      evidence: ["Citizen photo: Standard plastic bin overflowing."],
      credibility_score: 8,
      affected_population_estimate: 80,
      recommended_action: "Re-route waste collection vehicle to clear overflowing bin and deploy plaza sweeper.",
      assigned_department: "Waste Management",
      resolution_sla_hours: 72,
      duplicate_of: null,
      civic_points_awarded: 10,
      map_marker: { color: "#EAB308", icon: "Trash", tooltip: "Citizen Alert: Overflowing waste bin at Metro Plaza" },
      predictive_flag: false,
      escalation_required: false,
      status: "Resolved",
      verifications_count: 5,
      verified_by: ["user_alice", "citizen_clara", "verifier_bob"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 72 * 3600000).toISOString(), note: "Citizen reported overflowing waste container." },
        { status: "Verified", timestamp: new Date(Date.now() - 70 * 3600000).toISOString(), note: "Verified by local community." },
        { status: "Assigned", timestamp: new Date(Date.now() - 68 * 3600000).toISOString(), note: "Scheduled for sanitation dispatch." },
        { status: "In Progress", timestamp: new Date(Date.now() - 48 * 3600000).toISOString(), note: "Sanitation truck clearing bins on plaza route." },
        { status: "Resolved", timestamp: new Date(Date.now() - 47 * 3600000).toISOString(), note: "Plaza bins emptied, surrounding area swept and cleared." }
      ],
      eta_days: 0,
      repair_cost_estimate: 80
    },
    {
      issue_id: "pred-a7d2-432a-bb39-6523cf87a2c1",
      timestamp: new Date(Date.now() - 96 * 3600000).toISOString(),
      source: "sensor",
      issue_type: "uneven surface",
      priority: "LOW",
      location: { lat: 40.7224, lng: -74.0031, address: "Pine Lane Pavement Corridor", ward: "Ward 4" },
      description: "Dynamic elevation sensor ELEV-305 registered a deviation of 2.8 cm (Threshold is 2.5 cm) on Pine Lane over 5 consecutive vehicle traverses, signaling early-stage subgrade compaction failure.",
      evidence: ["Sensor reading: ELEV-305 deviation 2.8 cm", "Vibration baseline delta +15%"],
      credibility_score: 10,
      affected_population_estimate: 15,
      recommended_action: "Schedule minor pavement profiling or micro-surfacing during upcoming seasonal road maintenance queue.",
      assigned_department: "Transport",
      resolution_sla_hours: 168,
      duplicate_of: null,
      civic_points_awarded: 10,
      map_marker: { color: "#22C55E", icon: "Activity", tooltip: "ELEV-305: Pavement Elevation Warning (LOW)" },
      predictive_flag: true,
      escalation_required: false,
      status: "Reported",
      verifications_count: 1,
      verified_by: ["system_admin"],
      history: [
        { status: "Reported", timestamp: new Date(Date.now() - 96 * 3600000).toISOString(), note: "AI Predictive risk flag generated based on elevation deviation logs." }
      ],
      eta_days: 6,
      repair_cost_estimate: 850
    }
  ];

  const initialUserProfile = {
    email: "ayanshisolanki@gmail.com",
    points: 120,
    rank: "Reporter",
    streak: 4,
    lastActive: new Date().toISOString(),
    achievements: ["First Alert", "Camera Eye", "Street Guardian"]
  };

  const initialDepartments = [
    { name: "Transport", active_tickets: 2, resolved_tickets: 14, sla_compliance: 94, performance_score: 91, avg_resolution_hours: 18 },
    { name: "Water & Sanitation", active_tickets: 1, resolved_tickets: 22, sla_compliance: 88, performance_score: 86, avg_resolution_hours: 24 },
    { name: "Energy", active_tickets: 1, resolved_tickets: 31, sla_compliance: 97, performance_score: 96, avg_resolution_hours: 8 },
    { name: "Waste Management", active_tickets: 0, resolved_tickets: 54, sla_compliance: 99, performance_score: 98, avg_resolution_hours: 4 },
    { name: "Public Works", active_tickets: 1, resolved_tickets: 9, sla_compliance: 82, performance_score: 80, avg_resolution_hours: 55 },
    { name: "Safety", active_tickets: 1, resolved_tickets: 19, sla_compliance: 95, performance_score: 93, avg_resolution_hours: 1.5 }
  ];

  const initialData = {
    issues: initialIssues,
    userProfile: initialUserProfile,
    departments: initialDepartments,
    lastUpdate: new Date().toISOString()
  };

  fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), "utf-8");
}

initDatabase();

// Database read/write helpers
function readDB() {
  initDatabase();
  const raw = fs.readFileSync(DB_FILE, "utf-8");
  return JSON.parse(raw);
}

function writeDB(data: any) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API ROUTE 1: Get all processed issues and core stats
  app.get("/api/issues", (req, res) => {
    try {
      const db = readDB();
      res.json(db);
    } catch (e: any) {
      res.status(500).json({ error: "Failed to read database", message: e.message });
    }
  });

  // API ROUTE 2: Get user profile
  app.get("/api/user/profile", (req, res) => {
    try {
      const db = readDB();
      res.json(db.userProfile);
    } catch (e: any) {
      res.status(500).json({ error: "Failed to read user profile" });
    }
  });

  // API ROUTE 3: Claim streak bonus
  app.post("/api/user/claim-streak", (req, res) => {
    try {
      const db = readDB();
      if (db.userProfile.streak >= 7) {
        db.userProfile.points += 100;
        db.userProfile.streak = 0; // reset
        if (!db.userProfile.achievements.includes("Streak Master")) {
          db.userProfile.achievements.push("Streak Master");
        }
        db.userProfile.lastActive = new Date().toISOString();
        
        // Recalculate Rank
        updateRank(db.userProfile);
        
        writeDB(db);
        res.json({ success: true, userProfile: db.userProfile, message: "Claimed +100 Streak Bonus!" });
      } else {
        res.status(400).json({ error: "Streak threshold (7 days) not met yet." });
      }
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Rank progression decider
  function updateRank(profile: any) {
    const pts = profile.points;
    if (pts >= 300) profile.rank = "Community Hero";
    else if (pts >= 200) profile.rank = "Civic Champion";
    else if (pts >= 100) profile.rank = "Validator";
    else if (pts >= 50) profile.rank = "Reporter";
    else profile.rank = "Observer";
  }

  // API ROUTE 4: Verify another citizen's report
  app.post("/api/issues/verify", (req, res) => {
    try {
      const { issue_id, user_email } = req.body;
      const db = readDB();
      const issue = db.issues.find((i: any) => i.issue_id === issue_id);
      
      if (!issue) {
        return res.status(404).json({ error: "Issue not found" });
      }

      if (issue.status === "Resolved") {
        return res.status(400).json({ error: "Issue is already resolved" });
      }

      if (issue.verified_by.includes(user_email)) {
        return res.status(400).json({ error: "You have already verified this report." });
      }

      // Add to verified list
      issue.verified_by.push(user_email);
      issue.verifications_count += 1;

      // Add verification log
      issue.history.push({
        status: issue.status,
        timestamp: new Date().toISOString(),
        note: `Community verification added by ${user_email}`
      });

      // Award 5 points to validator
      db.userProfile.points += 5;
      
      // If verifications count hits 3, auto promote to "Verified" if was "Reported"
      if (issue.verifications_count >= 3) {
        if (issue.status === "Reported") {
          issue.status = "Verified";
          issue.history.push({
            status: "Verified",
            timestamp: new Date().toISOString(),
            note: "Automatic promotion to VERIFIED state via community verification threshold (3+)."
          });
        }
        
        // Award additional 30 points to the original reporter if it was citizen-reported
        if (issue.source === "citizen") {
          // In real life, find the reporter. Here, let's award +30 to the active user profile as they are engaged!
          db.userProfile.points += 30;
          if (!db.userProfile.achievements.includes("Validator Star")) {
            db.userProfile.achievements.push("Validator Star");
          }
        }
      }

      updateRank(db.userProfile);
      writeDB(db);

      res.json({ success: true, issue, userProfile: db.userProfile });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // API ROUTE 5: Resolve an issue (Simulates public worker completing repair)
  app.post("/api/issues/resolve", (req, res) => {
    try {
      const { issue_id } = req.body;
      const db = readDB();
      const issue = db.issues.find((i: any) => i.issue_id === issue_id);

      if (!issue) {
        return res.status(404).json({ error: "Issue not found" });
      }

      issue.status = "Resolved";
      issue.history.push({
        status: "Resolved",
        timestamp: new Date().toISOString(),
        note: "Maintenance team verified repair work completed. Service fully restored."
      });
      issue.eta_days = 0;

      // Award 50 points to reporter
      db.userProfile.points += 50;
      if (!db.userProfile.achievements.includes("Solver")) {
        db.userProfile.achievements.push("Solver");
      }

      updateRank(db.userProfile);
      
      // Update department metrics
      const dept = db.departments.find((d: any) => d.name === issue.assigned_department);
      if (dept) {
        dept.active_tickets = Math.max(0, dept.active_tickets - 1);
        dept.resolved_tickets += 1;
        // Improve SLA compliance slightly
        dept.sla_compliance = Math.min(100, Math.round(dept.sla_compliance + 0.5));
        dept.performance_score = Math.min(100, Math.round(dept.performance_score + 1));
      }

      writeDB(db);
      res.json({ success: true, issue, userProfile: db.userProfile });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // API ROUTE 6: Parse Citizen Unstructured Input using Gemini AI
  app.post("/api/issues/create-citizen", async (req, res) => {
    const { text, coordinates, imageIncluded } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Report text is required" });
    }

    const db = readDB();
    const lat = coordinates?.lat || (40.7100 + (Math.random() - 0.5) * 0.02);
    const lng = coordinates?.lng || (-74.0050 + (Math.random() - 0.5) * 0.02);

    // Dynamic deduplication: Check if there's any active ticket within ~150 meters (roughly 0.0015 lat/lng delta)
    // and has a similar category or keyword
    let duplicateOfId: string | null = null;
    const existingSimilar = db.issues.find((iss: any) => {
      if (iss.status === "Resolved") return false;
      const latDelta = Math.abs(iss.location.lat - lat);
      const lngDelta = Math.abs(iss.location.lng - lng);
      const isNearby = latDelta < 0.0015 && lngDelta < 0.0015;
      
      // Simple keyword match
      const currentLower = text.toLowerCase();
      const existingTypeLower = iss.issue_type.toLowerCase();
      const isSimilarType = currentLower.includes(existingTypeLower) || existingTypeLower.includes(currentLower);
      
      return isNearby && isSimilarType;
    });

    if (existingSimilar) {
      duplicateOfId = existingSimilar.issue_id;
    }

    let aiResult: any = null;

    if (ai) {
      try {
        const systemPrompt = `You are the CivicPulse AI Citizen Engagement core. Analyze unstructured community text reports, categorize, prioritize, and structure them into formal municipal alerts.
        
        Our ISSUE TAXONOMY covers:
        - Road: pothole, crack, uneven surface, sinkholes, road marking fade
        - Water: leakage, flooding, blocked drain, broken pipe
        - Electricity: streetlight outage, exposed wiring, transformer issue
        - Waste: overflowing bin, illegal dumping, missed collection
        - Structure: damaged bridge, broken railing, collapsed wall, damaged bench
        - Environment: tree fall risk, waterlogging, air quality, noise
        - Safety: damaged signage, missing manhole cover, broken traffic signal

        OUR PRIORITY CLASSIFICATION RULES:
        1. CRITICAL (Immediate): Safety risk to life, complete infrastructure collapse, affects 500+ people. (e.g. exposed live wires, missing manhole covers, bridge structural alerts). SLA: 2 hours.
        2. HIGH (Urgent): Significant danger/damage, major arterial road blocks, affects 100-500 people. SLA: 24 hours.
        3. MEDIUM (Scheduled): Moderate impact, not life-threatening, affects 20-100 people. SLA: 72 hours.
        4. LOW (Planned): Cosmetic, minor, early-stage, affects < 20 people. SLA: 168 hours.

        Return a strictly JSON schema containing:
        {
          "issue_type": "string from the taxonomy",
          "priority": "CRITICAL | HIGH | MEDIUM | LOW",
          "description": "highly technical plain language summary of the citizen report",
          "credibility_score": integer (1-10 based on detail level, precise locations described, or mention of photos),
          "affected_population_estimate": integer,
          "recommended_action": "concrete corrective action for dispatch teams",
          "assigned_department": "Transport | Water & Sanitation | Energy | Waste Management | Public Works | Safety",
          "resolution_sla_hours": integer (SLA hours based on priority: CRITICAL=2, HIGH=24, MEDIUM=72, LOW=168),
          "civic_points_awarded": integer (Base 10. If detailed text +10. If photo/evidence is mentioned +20. Range: 10 to 30),
          "map_marker": {
            "color": "Hex color e.g. #EF4444 for CRITICAL, #F97316 for HIGH, #EAB308 for MEDIUM, #22C55E for LOW",
            "icon": "Lucide React icon name suitable for the category: TriangleAlert, Droplets, Lightbulb, Trash, Drill, Trees, ShieldAlert, AlertOctagon",
            "tooltip": "Brief tooltip summary (max 40 chars)"
          },
          "predictive_flag": false,
          "escalation_required": boolean (true if priority is CRITICAL)
        }`;

        const prompt = `Citizen Report Input: "${text}"
        Image Attachment Included: ${imageIncluded ? "Yes" : "No"}`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                issue_type: { type: Type.STRING },
                priority: { type: Type.STRING },
                description: { type: Type.STRING },
                credibility_score: { type: Type.INTEGER },
                affected_population_estimate: { type: Type.INTEGER },
                recommended_action: { type: Type.STRING },
                assigned_department: { type: Type.STRING },
                resolution_sla_hours: { type: Type.INTEGER },
                civic_points_awarded: { type: Type.INTEGER },
                map_marker: {
                  type: Type.OBJECT,
                  properties: {
                    color: { type: Type.STRING },
                    icon: { type: Type.STRING },
                    tooltip: { type: Type.STRING }
                  },
                  required: ["color", "icon", "tooltip"]
                },
                predictive_flag: { type: Type.BOOLEAN },
                escalation_required: { type: Type.BOOLEAN }
              },
              required: [
                "issue_type", "priority", "description", "credibility_score",
                "affected_population_estimate", "recommended_action", "assigned_department",
                "resolution_sla_hours", "civic_points_awarded", "map_marker",
                "predictive_flag", "escalation_required"
              ]
            }
          }
        });

        if (response.text) {
          aiResult = JSON.parse(response.text.trim());
        }
      } catch (err: any) {
        console.error("Gemini Citizen Parsing Error:", err);
      }
    }

    // Fallback if AI not setup or fails
    if (!aiResult) {
      console.log("Using rule-based fallback for Citizen processing");
      const textLower = text.toLowerCase();
      let issue_type = "pothole";
      let assigned_department = "Transport";
      let icon = "TriangleAlert";
      let color = "#F97316";
      let priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" = "HIGH";
      let sla = 24;

      if (textLower.includes("wire") || textLower.includes("electricity") || textLower.includes("live wire")) {
        issue_type = "exposed wiring";
        assigned_department = "Safety";
        priority = "CRITICAL";
        color = "#EF4444";
        icon = "ShieldAlert";
        sla = 2;
      } else if (textLower.includes("water") || textLower.includes("flooding") || textLower.includes("leak") || textLower.includes("drain")) {
        issue_type = textLower.includes("pipe") ? "broken pipe" : "flooding";
        assigned_department = "Water & Sanitation";
        icon = "Droplets";
        priority = "HIGH";
        color = "#F97316";
        sla = 24;
      } else if (textLower.includes("light") || textLower.includes("dark") || textLower.includes("streetlight")) {
        issue_type = "streetlight outage";
        assigned_department = "Energy";
        icon = "Lightbulb";
        priority = "MEDIUM";
        color = "#EAB308";
        sla = 72;
      } else if (textLower.includes("trash") || textLower.includes("waste") || textLower.includes("bin") || textLower.includes("dumping")) {
        issue_type = "overflowing bin";
        assigned_department = "Waste Management";
        icon = "Trash";
        priority = "MEDIUM";
        color = "#EAB308";
        sla = 72;
      } else if (textLower.includes("manhole")) {
        issue_type = "missing manhole cover";
        assigned_department = "Safety";
        priority = "CRITICAL";
        color = "#EF4444";
        icon = "ShieldAlert";
        sla = 2;
      }

      aiResult = {
        issue_type,
        priority,
        description: `Citizen-reported event: "${text}"`,
        credibility_score: imageIncluded ? 8 : 5,
        affected_population_estimate: priority === "CRITICAL" ? 550 : priority === "HIGH" ? 180 : 35,
        recommended_action: `Dispatch team for immediate field investigation of ${issue_type}.`,
        assigned_department,
        resolution_sla_hours: sla,
        civic_points_awarded: imageIncluded ? 20 : 10,
        map_marker: {
          color,
          icon,
          tooltip: `Citizen report: ${issue_type}`
        },
        predictive_flag: false,
        escalation_required: priority === "CRITICAL"
      };
    }

    // Compose the full issue record
    const uuid = "citizen-" + Math.random().toString(36).substr(2, 9);
    const newIssue: any = {
      issue_id: uuid,
      timestamp: new Date().toISOString(),
      source: "citizen",
      issue_type: aiResult.issue_type,
      priority: aiResult.priority,
      location: {
        lat,
        lng,
        address: coordinates?.address || `Near ${Math.round(lat*1000)/1000}, ${Math.round(lng*1000)/1000}, Ward 4`,
        ward: "Ward 4"
      },
      description: aiResult.description,
      evidence: imageIncluded ? ["Citizen uploaded picture"] : ["Text submission logs"],
      credibility_score: aiResult.credibility_score,
      affected_population_estimate: aiResult.affected_population_estimate,
      recommended_action: aiResult.recommended_action,
      assigned_department: aiResult.assigned_department,
      resolution_sla_hours: aiResult.resolution_sla_hours,
      duplicate_of: duplicateOfId,
      civic_points_awarded: duplicateOfId ? 0 : aiResult.civic_points_awarded,
      map_marker: aiResult.map_marker,
      predictive_flag: aiResult.predictive_flag,
      escalation_required: aiResult.escalation_required,
      status: "Reported",
      verifications_count: 1,
      verified_by: ["active_user"],
      history: [
        { status: "Reported", timestamp: new Date().toISOString(), note: `Logged via citizen mobile core. Raw assessment accuracy calculated at ${aiResult.credibility_score*10}%.` }
      ],
      eta_days: aiResult.resolution_sla_hours / 24,
      repair_cost_estimate: aiResult.priority === "CRITICAL" ? 3000 : aiResult.priority === "HIGH" ? 1200 : 350
    };

    // If it's not a duplicate, save to issues list and credit user points
    if (!duplicateOfId) {
      db.issues.unshift(newIssue);
      db.userProfile.points += aiResult.civic_points_awarded;
      updateRank(db.userProfile);

      // Increment active tickets for department
      const dept = db.departments.find((d: any) => d.name === aiResult.assigned_department);
      if (dept) {
        dept.active_tickets += 1;
      }
    } else {
      // Just add comment logs to the duplicate ticket
      const orig = db.issues.find((i: any) => i.issue_id === duplicateOfId);
      if (orig) {
        orig.history.push({
          status: orig.status,
          timestamp: new Date().toISOString(),
          note: `De-duplicated report matched: Citizen submitted similar observation: "${text}".`
        });
      }
    }

    writeDB(db);

    res.json({
      success: true,
      duplicate: !!duplicateOfId,
      issue: newIssue,
      userProfile: db.userProfile
    });
  });

  // API ROUTE 7: Parse IoT Sensor Payload using Gemini AI
  app.post("/api/issues/parse-sensor", async (req, res) => {
    const payload = req.body;

    if (!payload || !payload.sensor_id || !payload.type) {
      return res.status(400).json({ error: "Invalid sensor payload. Required: sensor_id, type" });
    }

    const db = readDB();

    let aiResult: any = null;

    if (ai) {
      try {
        const systemPrompt = `You are the CivicPulse AI Hardware Sensor engine. Analyze raw telemetry data from municipal smart-sensors (vibrational, photometric, ultrasonic, stress, elevation, moisture) and translate the anomaly into a structured hazard report.
        
        Our ISSUE TAXONOMY covers:
        - Road: pothole, crack, uneven surface, sinkholes
        - Water: leakage, flooding, blocked drain, broken pipe
        - Electricity: streetlight outage, exposed wiring, transformer issue
        - Waste: overflowing bin, illegal dumping
        - Structure: damaged bridge, broken railing, collapsed wall
        
        OUR PRIORITY CLASSIFICATION RULES:
        1. CRITICAL (Immediate): Safety risk to life, complete collapse. (e.g. bridge structural alerts, exposed live wires, moisture sensor flood alerts with consecutive breaches > 5).
        2. HIGH (Urgent): Significant inconvenience, potential to fail quickly. (e.g. pothole on main road with high vibration G-delta, streetlight blackout).
        3. MEDIUM (Scheduled): Moderate drift, bin overflow.
        4. LOW (Planned): Minor deviations.

        Return a strictly JSON schema containing:
        {
          "issue_type": "string from the taxonomy",
          "priority": "CRITICAL | HIGH | MEDIUM | LOW",
          "description": "highly professional engineering report of the sensor anomaly",
          "affected_population_estimate": integer,
          "recommended_action": "maintenance dispatch corrective recommendation",
          "assigned_department": "Transport | Water & Sanitation | Energy | Waste Management | Public Works | Safety",
          "resolution_sla_hours": integer (SLA hours based on priority: CRITICAL=2, HIGH=24, MEDIUM=72, LOW=168),
          "map_marker": {
            "color": "Hex color e.g. #EF4444 for CRITICAL, #F97316 for HIGH, #EAB308 for MEDIUM, #22C55E for LOW",
            "icon": "Lucide React icon key (e.g., Activity, AlertOctagon, LightbulbOff, Trash, Droplet, Trees, Hammer)",
            "tooltip": "Brief sensor tooltip (max 45 chars)"
          },
          "predictive_flag": boolean (true if sensor deviation indicates a pattern of degradation over time),
          "escalation_required": boolean (true if threshold breach is high & priority is CRITICAL)
        }`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: `Parse Sensor Payload: ${JSON.stringify(payload)}`,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                issue_type: { type: Type.STRING },
                priority: { type: Type.STRING },
                description: { type: Type.STRING },
                affected_population_estimate: { type: Type.INTEGER },
                recommended_action: { type: Type.STRING },
                assigned_department: { type: Type.STRING },
                resolution_sla_hours: { type: Type.INTEGER },
                map_marker: {
                  type: Type.OBJECT,
                  properties: {
                    color: { type: Type.STRING },
                    icon: { type: Type.STRING },
                    tooltip: { type: Type.STRING }
                  },
                  required: ["color", "icon", "tooltip"]
                },
                predictive_flag: { type: Type.BOOLEAN },
                escalation_required: { type: Type.BOOLEAN }
              },
              required: [
                "issue_type", "priority", "description",
                "affected_population_estimate", "recommended_action", "assigned_department",
                "resolution_sla_hours", "map_marker", "predictive_flag", "escalation_required"
              ]
            }
          }
        });

        if (response.text) {
          aiResult = JSON.parse(response.text.trim());
        }
      } catch (err: any) {
        console.error("Gemini Sensor Parsing Error:", err);
      }
    }

    if (!aiResult) {
      console.log("Using rule-based fallback for Sensor processing");
      let issue_type = "pothole";
      let assigned_department = "Transport";
      let priority = "MEDIUM";
      let color = "#EAB308";
      let icon = "Activity";
      let sla = 72;

      if (payload.type === "road_vibration") {
        issue_type = "pothole";
        priority = payload.reading > 3.5 ? "HIGH" : "MEDIUM";
        color = priority === "HIGH" ? "#F97316" : "#EAB308";
        icon = "Activity";
        sla = priority === "HIGH" ? 24 : 72;
      } else if (payload.type === "elevation") {
        issue_type = "uneven surface";
        priority = (payload.deviation_mm || payload.reading) > 25 ? "HIGH" : "LOW";
        color = priority === "HIGH" ? "#F97316" : "#22C55E";
        icon = "TrendingUp";
        sla = priority === "HIGH" ? 24 : 168;
      } else if (payload.type === "moisture") {
        issue_type = "flooding";
        assigned_department = "Water & Sanitation";
        priority = payload.reading > 80 ? "CRITICAL" : "HIGH";
        color = priority === "CRITICAL" ? "#EF4444" : "#F97316";
        icon = "Droplet";
        sla = priority === "CRITICAL" ? 2 : 24;
      } else if (payload.type === "photometric") {
        issue_type = "streetlight outage";
        assigned_department = "Energy";
        priority = "HIGH";
        color = "#F97316";
        icon = "LightbulbOff";
        sla = 24;
      } else if (payload.type === "ultrasonic") {
        issue_type = "overflowing bin";
        assigned_department = "Waste Management";
        priority = "MEDIUM";
        color = "#EAB308";
        icon = "Trash";
        sla = 72;
      } else if (payload.type === "structural") {
        issue_type = "damaged bridge";
        assigned_department = "Public Works";
        priority = "CRITICAL";
        color = "#EF4444";
        icon = "AlertOctagon";
        sla = 2;
      }

      aiResult = {
        issue_type,
        priority,
        description: `IoT Anomaly from Sensor ${payload.sensor_id} [Type: ${payload.type}]. Unit reading: ${payload.reading} ${payload.unit || ''}.`,
        affected_population_estimate: priority === "CRITICAL" ? 750 : 150,
        recommended_action: `Dispatch dedicated ${assigned_department} field unit to inspect telemetry discrepancy.`,
        assigned_department,
        resolution_sla_hours: sla,
        map_marker: {
          color,
          icon,
          tooltip: `${payload.sensor_id}: ${payload.type} Alert`
        },
        predictive_flag: payload.consecutive_anomalies > 4,
        escalation_required: priority === "CRITICAL"
      };
    }

    // Check duplication for sensor (sensor ID match or coordinate exact overlap)
    const duplicate = db.issues.find((i: any) => i.description.includes(payload.sensor_id) && i.status !== "Resolved");

    if (duplicate) {
      duplicate.history.push({
        status: duplicate.status,
        timestamp: new Date().toISOString(),
        note: `Telemetry updated. Sensor reported consecutive breach #${payload.consecutive_anomalies || 1}. Reading: ${payload.reading} ${payload.unit || ''}.`
      });
      writeDB(db);
      return res.json({ success: true, duplicate: true, issue: duplicate });
    }

    const uuid = "sensor-" + Math.random().toString(36).substr(2, 9);
    const newIssue: any = {
      issue_id: uuid,
      timestamp: payload.timestamp || new Date().toISOString(),
      source: "sensor",
      issue_type: aiResult.issue_type,
      priority: aiResult.priority,
      location: {
        lat: payload.location?.lat || 40.7100,
        lng: payload.location?.lng || -74.0050,
        address: payload.location?.road_name || "Telemetry Node Cluster",
        ward: "Ward 4"
      },
      description: aiResult.description,
      evidence: [`Raw sensor reading: ${payload.reading} ${payload.unit || ''}`, `Breach flag: ${payload.threshold_breach}`, `Sensor Node ID: ${payload.sensor_id}`],
      credibility_score: 10, // Sensors are 100% credible
      affected_population_estimate: aiResult.affected_population_estimate,
      recommended_action: aiResult.recommended_action,
      assigned_department: aiResult.assigned_department,
      resolution_sla_hours: aiResult.resolution_sla_hours,
      duplicate_of: null,
      civic_points_awarded: 0, // No points for hardware sensors
      map_marker: aiResult.map_marker,
      predictive_flag: aiResult.predictive_flag,
      escalation_required: aiResult.escalation_required,
      status: "Reported",
      verifications_count: 1,
      verified_by: ["system_telemetry"],
      history: [
        { status: "Reported", timestamp: new Date().toISOString(), note: `Logged automatically via cellular telemetry pipeline. Escalation status: ${aiResult.escalation_required ? "ACTIVE" : "NONE"}.` }
      ],
      eta_days: aiResult.resolution_sla_hours / 24,
      repair_cost_estimate: aiResult.priority === "CRITICAL" ? 8500 : aiResult.priority === "HIGH" ? 2200 : 400
    };

    db.issues.unshift(newIssue);

    // Increment active tickets for department
    const dept = db.departments.find((d: any) => d.name === aiResult.assigned_department);
    if (dept) {
      dept.active_tickets += 1;
    }

    writeDB(db);

    res.json({ success: true, duplicate: false, issue: newIssue });
  });

  // API ROUTE 8: Generate Weekly Predictive & Operational AI report
  app.get("/api/predictive/risk-report", async (req, res) => {
    const db = readDB();
    const activeIssues = db.issues.filter((i: any) => i.status !== "Resolved");

    let reportText = "";

    if (ai) {
      try {
        const prompt = `You are the CivicPulse AI lead urban planner and predictive analyst. Generate a highly technical "State of the Ward 4" predictive risk report.
        Here are the current active infrastructure issues:
        ${JSON.stringify(activeIssues.map(i => ({ type: i.issue_type, priority: i.priority, loc: i.location.address, dept: i.assigned_department, source: i.source })))}
        
        Analyze the risk profiles. Project current meteorological trends: summer rains leading to drainage strain, high temperatures adding expansion joint stress on bridges.
        
        Formulate a fully customized JSON response matching this schema:
        {
          "summary": "1-2 paragraph executive summary explaining the predictive risks, critical hotspots, and urgent infrastructure interventions for Ward 4.",
          "safety_index": integer (0 to 100 score of current public safety),
          "health_index": integer (0 to 100 score of sanitation, moisture levels, waste efficiency),
          "efficiency_index": integer (0 to 100 score of municipal work response speed),
          "aging_zones": [
            {
              "zone": "string e.g. North Grid, Riverfront, Central Corridor",
              "risk_factor": "CRITICAL | HIGH | MEDIUM | LOW",
              "risk_score": integer (1-100),
              "description": "engineering-level summary of aging patterns, structural fatigue, or systemic blockages observed in this zone"
            }
          ],
          "preventive_schedule": [
            {
              "target": "target asset e.g. West Crossing Bridge, South St Drainage Basin",
              "action": "preventive maintenance recommendation e.g. expansion joint re-sealing, silt dredging",
              "cost_est": integer (projected repair cost in USD),
              "priority": "HIGH | MEDIUM | LOW"
            }
          ]
        }`;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                summary: { type: Type.STRING },
                safety_index: { type: Type.INTEGER },
                health_index: { type: Type.INTEGER },
                efficiency_index: { type: Type.INTEGER },
                aging_zones: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      zone: { type: Type.STRING },
                      risk_factor: { type: Type.STRING },
                      risk_score: { type: Type.INTEGER },
                      description: { type: Type.STRING }
                    },
                    required: ["zone", "risk_factor", "risk_score", "description"]
                  }
                },
                preventive_schedule: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      target: { type: Type.STRING },
                      action: { type: Type.STRING },
                      cost_est: { type: Type.INTEGER },
                      priority: { type: Type.STRING }
                    },
                    required: ["target", "action", "cost_est", "priority"]
                  }
                }
              },
              required: ["summary", "safety_index", "health_index", "efficiency_index", "aging_zones", "preventive_schedule"]
            }
          }
        });

        if (response.text) {
          reportText = response.text.trim();
        }
      } catch (err) {
        console.error("Gemini report generation failed:", err);
      }
    }

    if (!reportText) {
      // Fallback rule-based JSON report
      const fallbackReport = {
        summary: "Ward 4 infrastructure demonstrates moderate strain. High structural stress detected on transit corridors like the West Crossing Bridge require lane closures, while localized storm drain blockages on South Street pose runoff pooling hazards. Proactive maintenance queues must prioritize drainage dredging and joint re-sealing to offset costly secondary failures.",
        safety_index: 78,
        health_index: 84,
        efficiency_index: 89,
        aging_zones: [
          {
            zone: "Riverfront & West Transit Crossing",
            risk_factor: "CRITICAL",
            risk_score: 92,
            description: "A combination of high truck vibration loads and concrete carbonation fatigue has resulted in micro-fractures near stress-bearing bridge expansion joints."
          },
          {
            zone: "Pine Street Commercial Sector",
            risk_factor: "MEDIUM",
            risk_score: 54,
            description: "High commercial traffic combined with historical soil subsidence has triggered uneven surfaces on bicycle pathways."
          }
        ],
        preventive_schedule: [
          {
            target: "West Crossing Bridge Spans",
            action: "Ultrasonic weld scanning and joint damper lubrication",
            cost_est: 8500,
            priority: "HIGH"
          },
          {
            target: "South Street Catch Basins",
            action: "Dredging sediment and deploying smart ultrasonic level sensors",
            cost_est: 3200,
            priority: "MEDIUM"
          }
        ]
      };
      reportText = JSON.stringify(fallbackReport);
    }

    try {
      res.json(JSON.parse(reportText));
    } catch (e) {
      res.status(500).json({ error: "Failed to parse predictive report JSON output" });
    }
  });

  // Serve static assets and integrate Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CivicPulse AI Server running on http://localhost:${PORT} [NODE_ENV=${process.env.NODE_ENV || 'development'}]`);
  });
}

startServer().catch((e) => {
  console.error("Critical server bootstrap error:", e);
});
