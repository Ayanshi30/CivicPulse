import { useState, useEffect } from "react";
import { 
  Building2, 
  Coins, 
  Flame, 
  Award, 
  Trophy, 
  Compass, 
  MapPin, 
  Zap, 
  RefreshCw, 
  Layers, 
  Bell, 
  CheckCircle, 
  Clock, 
  ShieldAlert, 
  AlertTriangle, 
  ArrowRight, 
  UserCheck, 
  ShieldCheck, 
  Activity,
  History,
  AlertOctagon,
  Wrench,
  HelpCircle,
  Eye,
  CheckCircle2,
  Menu,
  X,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { ProcessedIssue, UserProfile, DepartmentMetric, StateOfTheWardReport, SensorPayload } from "./types";
import InteractiveMap from "./components/InteractiveMap";
import IoTTerminal from "./components/IoTTerminal";
import CitizenTerminal from "./components/CitizenTerminal";
import DashboardStats from "./components/DashboardStats";
import CitizenLeaderboard from "./components/CitizenLeaderboard";
import PredictiveAIReport from "./components/PredictiveAIReport";

export default function App() {
  const [issues, setIssues] = useState<ProcessedIssue[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [departments, setDepartments] = useState<DepartmentMetric[]>([]);
  const [selectedIssue, setSelectedIssue] = useState<ProcessedIssue | null>(null);
  const [predictiveReport, setPredictiveReport] = useState<StateOfTheWardReport | null>(null);

  // Loading/Processing states
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isTransmittingIoT, setIsTransmittingIoT] = useState<boolean>(false);
  const [isProcessingCitizen, setIsProcessingCitizen] = useState<boolean>(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState<boolean>(false);
  const [isClaimingStreak, setIsClaimingStreak] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isResolving, setIsResolving] = useState<boolean>(false);

  // Active terminal tab
  const [activeTab, setActiveTab] = useState<"overview" | "iot" | "citizen" | "predictive" | "leaderboard">("overview");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Coordinates anchor from map clicking
  const [mapClickedCoords, setMapClickedCoords] = useState<{ lat: number; lng: number; address: string } | null>(null);

  // Notifications
  const [notification, setNotification] = useState<{ message: string; type: "success" | "info" | "warning" } | null>(null);

  // Fetch all database metrics on initial mount
  const fetchAllData = async () => {
    try {
      const res = await fetch("/api/issues");
      const data = await res.json();
      if (res.ok) {
        setIssues(data.issues);
        setUserProfile(data.userProfile);
        setDepartments(data.departments);

        // If an issue was previously selected, refresh its details from the updated list
        if (selectedIssue) {
          const updated = data.issues.find((i: ProcessedIssue) => i.issue_id === selectedIssue.issue_id);
          if (updated) setSelectedIssue(updated);
        } else if (data.issues.length > 0) {
          // Default to the first critical/high alert on first load
          setSelectedIssue(data.issues[0]);
        }
      }
    } catch (e) {
      console.error("Failed to sync client data", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Display a brief operational notification banner
  const triggerNotification = (message: string, type: "success" | "info" | "warning" = "info") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  // Pillar 1: Transmit IoT hardware sensor signals to backend
  const handleTransmitSensorSignal = async (payload: SensorPayload) => {
    setIsTransmittingIoT(true);
    try {
      const res = await fetch("/api/issues/parse-sensor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        await fetchAllData();
        triggerNotification(
          `IoT Telemetry Processed: ${data.issue.map_marker.tooltip} registered.`, 
          data.issue.priority === "CRITICAL" ? "warning" : "success"
        );
        setSelectedIssue(data.issue);
      } else {
        triggerNotification(data.error || "Failed to process sensor signal.", "warning");
      }
    } catch (e) {
      triggerNotification("Connection timeout during sensor transmission.", "warning");
    } finally {
      setIsTransmittingIoT(false);
    }
  };

  // Pillar 2: Process citizen unstructured report
  const handleSubmitCitizenReport = async (
    text: string, 
    coordinates: { lat: number; lng: number; address: string } | null, 
    imageIncluded: boolean
  ) => {
    setIsProcessingCitizen(true);
    try {
      const res = await fetch("/api/issues/create-citizen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, coordinates, imageIncluded })
      });
      const data = await res.json();
      if (res.ok) {
        await fetchAllData();
        if (data.duplicate) {
          triggerNotification("Citizen Report Deduplicated: Matched open hazard within 150m.", "info");
        } else {
          triggerNotification(`Incident Classified! Priority: ${data.issue.priority}. Earned +${data.issue.civic_points_awarded} Civic Points!`, "success");
          setSelectedIssue(data.issue);
        }
        return { success: true };
      } else {
        triggerNotification(data.error || "Failed to catalog citizen report.", "warning");
        return { success: false };
      }
    } catch (e) {
      triggerNotification("Communication error during citizen submission.", "warning");
      return { success: false };
    } finally {
      setIsProcessingCitizen(false);
    }
  };

  // Pillar 3: Generate Weekly AI Risk Report
  const handleGeneratePredictiveReport = async (): Promise<StateOfTheWardReport | null> => {
    setIsGeneratingReport(true);
    try {
      const res = await fetch("/api/predictive/risk-report");
      const data = await res.json();
      if (res.ok) {
        setPredictiveReport(data);
        triggerNotification("Weekly State of the Ward AI Report generated successfully.", "success");
        return data;
      } else {
        triggerNotification("Failed to compile predictive report.", "warning");
        return null;
      }
    } catch (e) {
      triggerNotification("Predictive AI core communication error.", "warning");
      return null;
    } finally {
      setIsGeneratingReport(false);
    }
  };

  // Gamification: Claim active 7-day streak
  const handleClaimStreak = async () => {
    if (!userProfile) return;
    setIsClaimingStreak(true);
    try {
      const res = await fetch("/api/user/claim-streak", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setUserProfile(data.userProfile);
        triggerNotification(data.message, "success");
        await fetchAllData();
      } else {
        triggerNotification(data.error, "warning");
      }
    } catch (e) {
      triggerNotification("Could not communicate with points server.", "warning");
    } finally {
      setIsClaimingStreak(false);
    }
  };

  // Peer-to-Peer Verification Loop
  const handleVerifyIssue = async () => {
    if (!selectedIssue || !userProfile) return;
    setIsVerifying(true);
    try {
      const res = await fetch("/api/issues/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ issue_id: selectedIssue.issue_id, user_email: userProfile.email })
      });
      const data = await res.json();
      if (res.ok) {
        await fetchAllData();
        setSelectedIssue(data.issue);
        triggerNotification("Community verification registered! Awarded +5 validator points.", "success");
      } else {
        triggerNotification(data.error, "warning");
      }
    } catch (e) {
      triggerNotification("Failed to register verification.", "warning");
    } finally {
      setIsVerifying(false);
    }
  };

  // Municipal Resolution (Simulated Repair work)
  const handleResolveIssue = async () => {
    if (!selectedIssue) return;
    setIsResolving(true);
    try {
      const res = await fetch("/api/issues/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ issue_id: selectedIssue.issue_id })
      });
      const data = await res.json();
      if (res.ok) {
        await fetchAllData();
        setSelectedIssue(data.issue);
        triggerNotification(`Issue resolved! Dispatch logs updated. Reporter awarded +50 points!`, "success");
      } else {
        triggerNotification(data.error, "warning");
      }
    } catch (e) {
      triggerNotification("Failed to finalize ticket resolution.", "warning");
    } finally {
      setIsResolving(false);
    }
  };

  // Coordinate projection from map clicking
  const handleMapClick = (coords: { lat: number; lng: number; address: string }) => {
    setMapClickedCoords(coords);
    setActiveTab("citizen"); // Switch tab automatically so they can see the pinned coordinate and file report!
    triggerNotification(`Location Pinned: ${coords.address}. Ready to report.`, "info");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex flex-col items-center justify-center text-[#E0E0E0] font-mono">
        <RefreshCw className="animate-spin text-[#3B82F6] mb-4" size={32} />
        <p className="text-sm tracking-wider font-semibold animate-pulse uppercase">BOOTSTRAPPING CIVICPULSE AI FRAMEWORK...</p>
        <p className="text-xs text-[#8E8E93] mt-2">Connecting to edge sensor nodes & local database layers</p>
      </div>
    );
  }

  // Pre-calculate counts of active issues
  const activeCount = issues.filter(i => i.status !== "Resolved").length;
  const resolvedCount = issues.filter(i => i.status === "Resolved").length;

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E0E0E0] flex flex-col md:flex-row relative overflow-hidden">
      
      {/* 1. Global Alert / Notification Banner */}
      {notification && (
        <div className={`fixed top-4 right-4 z-50 px-5 py-4.5 rounded-xl border shadow-2xl flex items-center space-x-3 transition-all duration-300 transform translate-y-0 max-w-sm font-mono text-xs ${
          notification.type === "success" ? "bg-[#141416]/95 text-[#2ECC71] border-[#2ECC71]/30" : 
          notification.type === "warning" ? "bg-[#141416]/95 text-[#FF4B2B] border-[#FF4B2B]/30 animate-pulse" : 
          "bg-[#141416]/95 text-[#60A5FA] border-[#2D2D2E]"
        }`}>
          <Bell size={16} className={notification.type === "warning" ? "animate-bounce text-[#FF4B2B]" : "text-[#2ECC71]"} />
          <span>{notification.message}</span>
        </div>
      )}

      {/* 2. Collapsible Left Sidebar (Desktop Only) */}
      <aside className={`bg-[#141416] border-r border-[#2D2D2E] flex flex-col justify-between transition-all duration-300 z-50 shrink-0 relative ${
        isSidebarCollapsed ? "w-20" : "w-64"
      } hidden md:flex`}>
        {/* Sidebar Header / Brand */}
        <div className="p-4 border-b border-[#2D2D2E] flex items-center justify-between h-[73px]">
          <div className="flex items-center space-x-3 overflow-hidden">
            <div className="bg-[#3B82F6]/10 p-2 rounded-xl border border-[#3B82F6]/20 shrink-0">
              <Activity className="text-[#3B82F6]" size={18} />
            </div>
            {!isSidebarCollapsed && (
              <div className="transition-opacity duration-300">
                <h1 className="font-display font-black text-sm tracking-wider text-white uppercase whitespace-nowrap">
                  CivicPulse AI
                </h1>
                <p className="text-[10px] text-[#8E8E93] font-mono whitespace-nowrap">v3.5 Live Core</p>
              </div>
            )}
          </div>
          
          <button 
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="text-[#8E8E93] hover:text-white p-1 rounded-lg hover:bg-[#1C1C1E] transition cursor-pointer"
            title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isSidebarCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        {/* Sidebar Navigation Links */}
        <div className="flex-1 py-6 px-3 space-y-1.5 overflow-y-auto">
          {[
            { id: "overview", name: "Command Map", icon: Compass, color: "text-[#3B82F6]" },
            { id: "iot", name: "IoT Sensors", icon: Activity, color: "text-[#3B82F6]" },
            { id: "citizen", name: "Citizen Corps", icon: UserCheck, color: "text-[#2ECC71]" },
            { id: "predictive", name: "Predictive AI", icon: ShieldAlert, color: "text-[#8B5CF6]" },
            { id: "leaderboard", name: "Civic Ledger", icon: Trophy, color: "text-[#FFD700]" },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as any);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center space-x-3 px-3 py-3 rounded-xl text-xs font-bold font-mono tracking-wider transition-all duration-200 cursor-pointer ${
                  isActive 
                    ? "bg-[#1C1C1E] text-white border border-[#2D2D2E]" 
                    : "text-[#8E8E93] hover:text-white hover:bg-[#111113]"
                }`}
              >
                <Icon className={`${isActive ? item.color : "text-[#8E8E93]"} shrink-0`} size={16} />
                {!isSidebarCollapsed && <span className="truncate">{item.name}</span>}
              </button>
            );
          })}
        </div>

        {/* Sidebar Footer User Card */}
        {userProfile && !isSidebarCollapsed && (
          <div className="p-4 border-t border-[#2D2D2E] bg-[#111113] m-3 rounded-xl space-y-2">
            <div className="flex items-center space-x-3">
              <div className="bg-[#FFD700]/10 p-1.5 rounded-lg border border-[#FFD700]/20">
                <Award className="text-[#FFD700]" size={14} />
              </div>
              <div className="overflow-hidden">
                <p className="text-[10px] font-bold text-white truncate">{userProfile.email}</p>
                <p className="text-[9px] text-[#8E8E93] font-mono truncate">{userProfile.rank}</p>
              </div>
            </div>
            
            <div className="flex justify-between items-center text-[10px] font-mono border-t border-[#2D2D2E] pt-2 mt-1">
              <span className="text-[#8E8E93] flex items-center"><Coins size={11} className="mr-1 text-[#FFD700]" /> {userProfile.points} pts</span>
              <span className="text-[#8E8E93] flex items-center"><Flame size={11} className="mr-1 text-[#FFA500]" /> {userProfile.streak}/7d</span>
            </div>
          </div>
        )}

        {/* Small badge if collapsed */}
        {userProfile && isSidebarCollapsed && (
          <div className="p-4 border-t border-[#2D2D2E] flex flex-col items-center space-y-3">
            <div className="bg-[#FFD700]/10 p-2 rounded-xl border border-[#FFD700]/20 text-[#FFD700]">
              <Award size={16} />
            </div>
          </div>
        )}
      </aside>

      {/* Mobile Header (Hamburger Menu) */}
      <header className="bg-[#141416] border-b border-[#2D2D2E] px-4 py-3 flex items-center justify-between md:hidden z-40 w-full shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="bg-[#3B82F6]/10 p-1.5 rounded-lg border border-[#3B82F6]/20">
            <Activity className="text-[#3B82F6]" size={16} />
          </div>
          <span className="font-display font-black text-sm tracking-wider text-white uppercase">CivicPulse AI</span>
        </div>
        
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="text-[#8E8E93] hover:text-white p-2 rounded-lg hover:bg-[#1C1C1E] transition cursor-pointer"
        >
          <Menu size={18} />
        </button>
      </header>

      {/* Mobile Drawer Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 md:hidden flex flex-row transition-all duration-300">
          <div className="bg-[#141416] w-72 h-full border-r border-[#2D2D2E] p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#2D2D2E]">
                <div className="flex items-center space-x-2">
                  <Activity className="text-[#3B82F6]" size={18} />
                  <span className="font-display font-bold text-sm text-white">CivicPulse AI Menu</span>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-[#8E8E93] hover:text-white p-1 rounded-lg hover:bg-[#1C1C1E] transition cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="py-6 space-y-2">
                {[
                  { id: "overview", name: "Command Map", icon: Compass, color: "text-[#3B82F6]" },
                  { id: "iot", name: "IoT Sensors", icon: Activity, color: "text-[#3B82F6]" },
                  { id: "citizen", name: "Citizen Corps", icon: UserCheck, color: "text-[#2ECC71]" },
                  { id: "predictive", name: "Predictive AI", icon: ShieldAlert, color: "text-[#8B5CF6]" },
                  { id: "leaderboard", name: "Civic Ledger", icon: Trophy, color: "text-[#FFD700]" },
                ].map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as any);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center space-x-3 px-3 py-3 rounded-xl text-xs font-bold font-mono tracking-wider transition cursor-pointer ${
                        isActive 
                          ? "bg-[#1C1C1E] text-white border border-[#2D2D2E]" 
                          : "text-[#8E8E93] hover:text-white"
                      }`}
                    >
                      <Icon className={`${isActive ? item.color : "text-[#8E8E93]"} shrink-0`} size={16} />
                      <span>{item.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {userProfile && (
              <div className="p-4 bg-[#111113] rounded-xl space-y-2 border border-[#2D2D2E]">
                <div className="flex items-center space-x-3">
                  <Award className="text-[#FFD700]" size={14} />
                  <div className="overflow-hidden">
                    <p className="text-[10px] font-bold text-white truncate">{userProfile.email}</p>
                    <p className="text-[9px] text-[#8E8E93] font-mono truncate">{userProfile.rank}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center text-[10px] font-mono border-t border-[#2D2D2E] pt-2">
                  <span className="text-[#8E8E93] flex items-center"><Coins size={11} className="mr-1 text-[#FFD700]" /> {userProfile.points} pts</span>
                  <span className="text-[#8E8E93] flex items-center"><Flame size={11} className="mr-1 text-[#FFA500]" /> {userProfile.streak}/7d</span>
                </div>
              </div>
            )}
          </div>
          <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />
        </div>
      )}

      {/* Main Content Pane */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        
        {/* Top-Level Header (Desktop Only) */}
        <header className="bg-[#141416] border-b border-[#2D2D2E] px-6 py-4 hidden md:flex md:items-center justify-between gap-4 z-40 relative">
          <div>
            <h2 className="font-display font-black text-sm tracking-wider text-white uppercase flex items-center">
              {activeTab === "overview" && "📍 COMMAND CENTER MAP & MONITORING"}
              {activeTab === "iot" && "⚡ IoT HARDWARE TELEMETRY STREAM"}
              {activeTab === "citizen" && "📣 CITIZEN CORPS ENGAGEMENT HUB"}
              {activeTab === "predictive" && "🧠 PREDICTIVE & OPERATIONAL AI"}
              {activeTab === "leaderboard" && "🏆 CIVIC LEDGER & ACHIEVEMENTS"}
            </h2>
            <p className="text-xs text-[#8E8E93] tracking-wide mt-0.5">
              {activeTab === "overview" && "Real-time municipal hazard grid and dispatched SLA response logs"}
              {activeTab === "iot" && "Live hardware sensor signals feeding direct into local municipal channels"}
              {activeTab === "citizen" && "File community incident reports and inspect localized coordinates"}
              {activeTab === "predictive" && "Weekly AI synthesized state of the ward, fatigue indexes, and costed schedule"}
              {activeTab === "leaderboard" && "Earn coins, unlock trophies, and complete active streaks via inspections"}
            </p>
          </div>

          {/* User ledger badges in Header */}
          {userProfile && (
            <div className="flex items-center space-x-6 bg-[#111113] border border-[#2D2D2E] rounded-xl px-4 py-2 font-mono text-xs shadow-inner shrink-0">
              <div>
                <span className="text-[#8E8E93] block text-[9px] uppercase font-bold">Ledger Balance</span>
                <span className="text-[#2ECC71] flex items-center font-bold">
                  <Coins size={13} className="mr-1 text-[#FFD700]" />
                  {userProfile.points} pts
                </span>
              </div>
              <div className="h-6 w-[1px] bg-[#2D2D2E]" />
              <div>
                <span className="text-[#8E8E93] block text-[9px] uppercase font-bold">Active Streak</span>
                <span className="text-[#FFA500] flex items-center font-bold">
                  <Flame size={13} className="mr-1" />
                  {userProfile.streak}/7 days
                </span>
              </div>
            </div>
          )}
        </header>

      {/* 3. Main Dashboard Bento Layout */}
      {activeTab === "overview" ? (
        <main className="flex-1 p-6 grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Map & Active issue details (Span 7) */}
        <div className="xl:col-span-7 space-y-6">
          
          {/* Interactive Map Component */}
          <div className="h-[480px]">
            <InteractiveMap 
              issues={issues}
              selectedIssue={selectedIssue}
              onSelectIssue={(issue) => {
                setSelectedIssue(issue);
                // Highlight issue details
              }}
              onMapClick={handleMapClick}
              predictedZones={predictiveReport?.aging_zones || []}
            />
          </div>

          {/* Selected Ticket Live Timeline & Accountability Details */}
          {selectedIssue ? (
            <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-6 glow-card">
              <div className="flex items-start justify-between pb-4 border-b border-[#2D2D2E]">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded font-mono text-[9px] font-bold uppercase" style={{ backgroundColor: `${selectedIssue.map_marker.color}25`, color: selectedIssue.map_marker.color }}>
                      {selectedIssue.priority} PRIORITY
                    </span>
                    <span className="text-[#8E8E93] font-mono text-[10px] uppercase">ID: {selectedIssue.issue_id.slice(0, 8)}</span>
                  </div>
                  <h3 className="font-display font-bold text-base text-white capitalize mt-1.5 flex items-center gap-2">
                    {selectedIssue.issue_type}
                  </h3>
                  <p className="text-xs text-[#8E8E93] font-mono flex items-center mt-1"><MapPin size={12} className="mr-1 text-[#8E8E93]" /> {selectedIssue.location.address}</p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono text-[#8E8E93] block uppercase font-bold">Assigned SLA Dept.</span>
                  <span className="font-display font-medium text-xs text-white mt-0.5 block">{selectedIssue.assigned_department}</span>
                </div>
              </div>

              {/* Core Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-mono text-[#8E8E93] uppercase block font-bold">AI Technical Diagnosis</span>
                    <p className="text-xs text-[#E0E0E0] leading-relaxed mt-1">{selectedIssue.description}</p>
                  </div>

                  {selectedIssue.evidence.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono text-[#8E8E93] uppercase block font-bold">Telemetry Evidence / Photo Attachments</span>
                      <div className="flex flex-col space-y-1.5 mt-1.5">
                        {selectedIssue.evidence.map((ev, idx) => (
                          <div key={idx} className="bg-[#111113] border border-[#2D2D2E] rounded-lg p-2.5 font-mono text-[10px] text-[#8E8E93] flex items-center">
                            {ev.includes("http") ? (
                              <div className="flex items-center space-x-2">
                                <span className="text-[#2ECC71]">📸 Citizen Photo:</span>
                                <a href={ev} target="_blank" rel="noopener noreferrer" className="text-[#3B82F6] hover:underline truncate max-w-[200px]">{ev}</a>
                              </div>
                            ) : (
                              <span>📊 {ev}</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 flex items-center justify-between font-mono text-[11px] text-[#8E8E93]">
                    <div>
                      <span className="text-[#8E8E93] block text-[9px] uppercase">Estimated Impact</span>
                      <span className="text-white">~{selectedIssue.affected_population_estimate} people affected</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[#8E8E93] block text-[9px] uppercase">Repair Cost Est.</span>
                      <span className="text-[#2ECC71] font-bold">${selectedIssue.repair_cost_estimate?.toLocaleString() || "N/A"}</span>
                    </div>
                  </div>
                </div>

                {/* Progress Timeline Tracker */}
                <div className="border-t md:border-t-0 md:border-l border-[#2D2D2E] md:pl-6 pt-4 md:pt-0 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-[#8E8E93] uppercase block font-bold">Operational Status Pipeline</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                      selectedIssue.status === "Resolved" ? "bg-[#2ECC71]/10 text-[#2ECC71] border border-[#2ECC71]/20" :
                      selectedIssue.status === "In Progress" ? "bg-[#3B82F6]/10 text-[#3B82F6] border border-[#3B82F6]/20" : "bg-[#1C1C1E] text-[#8E8E93]"
                    }`}>{selectedIssue.status.toUpperCase()}</span>
                  </div>

                  {/* Progressive Dots list */}
                  <div className="relative pl-5 space-y-4 before:absolute before:left-1.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#2D2D2E]">
                    {/* Reported */}
                    <div className="relative">
                      <div className={`absolute -left-5 top-1 w-3.5 h-3.5 rounded-full border border-[#141416] flex items-center justify-center ${
                        ["Reported", "Verified", "Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) ? "bg-[#3B82F6] text-white" : "bg-[#2D2D2E]"
                      }`}>
                        {["Reported", "Verified", "Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) && <CheckCircle size={8} />}
                      </div>
                      <h5 className="text-[11px] font-bold text-white">Reported State</h5>
                      <p className="text-[9px] text-[#8E8E93] font-mono">{new Date(selectedIssue.timestamp).toLocaleTimeString()}</p>
                    </div>

                    {/* Verified */}
                    <div className="relative">
                      <div className={`absolute -left-5 top-1 w-3.5 h-3.5 rounded-full border border-[#141416] flex items-center justify-center ${
                        ["Verified", "Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) ? "bg-[#60A5FA] text-white" : "bg-[#2D2D2E]"
                      }`}>
                        {["Verified", "Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) && <CheckCircle size={8} />}
                      </div>
                      <h5 className="text-[11px] font-bold text-white">Community Verified</h5>
                      <p className="text-[9px] text-[#8E8E93] font-mono">Count: {selectedIssue.verifications_count} / 3 required</p>
                    </div>

                    {/* Assigned */}
                    <div className="relative">
                      <div className={`absolute -left-5 top-1 w-3.5 h-3.5 rounded-full border border-[#141416] flex items-center justify-center ${
                        ["Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) ? "bg-[#8B5CF6] text-white" : "bg-[#2D2D2E]"
                      }`}>
                        {["Assigned", "In Progress", "Resolved"].includes(selectedIssue.status) && <CheckCircle size={8} />}
                      </div>
                      <h5 className="text-[11px] font-bold text-white">Crew Dispatched</h5>
                      <p className="text-[9px] text-[#8E8E93] font-mono">Assigned to: {selectedIssue.assigned_department}</p>
                    </div>

                    {/* Resolved */}
                    <div className="relative">
                      <div className={`absolute -left-5 top-1 w-3.5 h-3.5 rounded-full border border-[#141416] flex items-center justify-center ${
                        selectedIssue.status === "Resolved" ? "bg-[#2ECC71] text-white animate-pulse" : "bg-[#2D2D2E]"
                      }`}>
                        {selectedIssue.status === "Resolved" && <CheckCircle size={8} />}
                      </div>
                      <h5 className="text-[11px] font-bold text-white">Restored & Closed</h5>
                      <p className="text-[9px] text-[#8E8E93] font-mono">SLA: &lt;{selectedIssue.resolution_sla_hours} hours limit</p>
                    </div>
                  </div>

                  {/* Active logs collapse */}
                  <div className="bg-[#111113] rounded-xl p-3 max-h-[100px] overflow-y-auto border border-[#2D2D2E]">
                    <span className="text-[9px] font-mono text-[#8E8E93] uppercase flex items-center mb-1.5"><History size={10} className="mr-1"/> Operational Logs:</span>
                    <div className="space-y-1 text-[9px] font-mono text-[#8E8E93]">
                      {selectedIssue.history.map((hist, idx) => (
                        <p key={idx} className="border-b border-[#2D2D2E]/40 pb-1">
                          <strong className="text-white">[{new Date(hist.timestamp).toLocaleTimeString()}]</strong> - {hist.note}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons to interact with the selected Ticket */}
              {selectedIssue.status !== "Resolved" && (
                <div className="flex items-center space-x-3 border-t border-[#2D2D2E] mt-6 pt-4">
                  {/* Verification Button */}
                  <button
                    onClick={handleVerifyIssue}
                    disabled={isVerifying || selectedIssue.verified_by.includes(userProfile?.email || "")}
                    className="flex-1 bg-[#111113] hover:bg-[#1C1C1E] disabled:bg-[#111113]/50 border border-[#2D2D2E] hover:border-[#3B82F6]/50 text-[#8E8E93] hover:text-white py-2.5 rounded-xl text-xs font-semibold font-mono tracking-wide flex items-center justify-center transition disabled:opacity-40 cursor-pointer"
                  >
                    {isVerifying ? (
                      <RefreshCw className="animate-spin mr-2" size={13} />
                    ) : (
                      <UserCheck className="mr-2 text-[#3B82F6]" size={13} />
                    )}
                    {selectedIssue.verified_by.includes(userProfile?.email || "") 
                      ? "YOU VERIFIED THIS" 
                      : `VERIFY TICKET (+5 PTS)`
                    }
                  </button>

                  {/* Sim Resolve Button */}
                  <button
                    onClick={handleResolveIssue}
                    disabled={isResolving}
                    className="flex-1 bg-[#2ECC71]/10 hover:bg-[#2ECC71]/20 text-[#2ECC71] border border-[#2ECC71]/20 py-2.5 rounded-xl text-xs font-semibold font-mono tracking-wide flex items-center justify-center transition cursor-pointer"
                  >
                    {isResolving ? (
                      <RefreshCw className="animate-spin mr-2" size={13} />
                    ) : (
                      <CheckCircle2 className="mr-2" size={13} />
                    )}
                    RESOLVE HAZARD (+50 PTS)
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-8 text-center text-[#8E8E93] font-mono text-xs">
              Select an active coordinate or sensor pin on the map to review telemetry details and timelines.
            </div>
          )}

          {/* Department stats */}
          <DashboardStats 
            departments={departments}
            activeCount={activeCount}
            resolvedCount={resolvedCount}
          />
        </div>

        {/* Right Column: Dynamic Launchers (Span 5) */}
        <div className="xl:col-span-5 space-y-6">
          <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-6 space-y-4">
            <div>
              <h3 className="font-display font-black text-xs tracking-wider text-white uppercase flex items-center gap-2">
                <Layers className="text-[#3B82F6]" size={14} /> Quick Terminal Access
              </h3>
              <p className="text-[11px] text-[#8E8E93] mt-1 leading-relaxed">
                Access dedicated command terminals directly or use the persistent sidebar on the left.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setActiveTab("iot")}
                className="bg-[#111113] hover:bg-[#1C1C1E] border border-[#2D2D2E] p-3 rounded-xl text-left transition cursor-pointer flex flex-col justify-between h-[85px] group"
              >
                <Activity size={16} className="text-[#3B82F6] transition-transform group-hover:scale-110" />
                <div>
                  <div className="font-mono text-[10px] font-bold text-white uppercase">IoT Streams</div>
                  <div className="text-[8px] text-[#8E8E93] font-mono font-bold">Edge Sensors</div>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("citizen")}
                className="bg-[#111113] hover:bg-[#1C1C1E] border border-[#2D2D2E] p-3 rounded-xl text-left transition cursor-pointer flex flex-col justify-between h-[85px] group"
              >
                <UserCheck size={16} className="text-[#2ECC71] transition-transform group-hover:scale-110" />
                <div>
                  <div className="font-mono text-[10px] font-bold text-white uppercase">Citizen Hub</div>
                  <div className="text-[8px] text-[#8E8E93] font-mono font-bold">Submit Reports</div>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("predictive")}
                className="bg-[#111113] hover:bg-[#1C1C1E] border border-[#2D2D2E] p-3 rounded-xl text-left transition cursor-pointer flex flex-col justify-between h-[85px] group"
              >
                <ShieldAlert size={16} className="text-[#8B5CF6] transition-transform group-hover:scale-110" />
                <div>
                  <div className="font-mono text-[10px] font-bold text-white uppercase">Predictive AI</div>
                  <div className="text-[8px] text-[#8E8E93] font-mono font-bold">Ward Reports</div>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("leaderboard")}
                className="bg-[#111113] hover:bg-[#1C1C1E] border border-[#2D2D2E] p-3 rounded-xl text-left transition cursor-pointer flex flex-col justify-between h-[85px] group"
              >
                <Trophy size={16} className="text-[#FFD700] transition-transform group-hover:scale-110" />
                <div>
                  <div className="font-mono text-[10px] font-bold text-white uppercase">Civic Ledger</div>
                  <div className="text-[8px] text-[#8E8E93] font-mono font-bold">Leaderboard</div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </main>
      ) : (
        <main className="flex-1 p-6 overflow-y-auto">
          {activeTab === "iot" && (
            <div className="max-w-5xl mx-auto">
              <IoTTerminal 
                onTransmitSignal={handleTransmitSensorSignal}
                isProcessing={isTransmittingIoT}
              />
            </div>
          )}

          {activeTab === "citizen" && (
            <div className="max-w-4xl mx-auto">
              <CitizenTerminal 
                onSubmitReport={handleSubmitCitizenReport}
                isProcessing={isProcessingCitizen}
                mapClickedCoords={mapClickedCoords}
                onClearCoords={() => setMapClickedCoords(null)}
              />
            </div>
          )}

          {activeTab === "predictive" && (
            <div className="max-w-5xl mx-auto">
              <PredictiveAIReport 
                onGenerateReport={handleGeneratePredictiveReport}
                isGenerating={isGeneratingReport}
                savedReport={predictiveReport}
              />
            </div>
          )}

          {activeTab === "leaderboard" && userProfile && (
            <div className="max-w-4xl mx-auto">
              <CitizenLeaderboard 
                profile={userProfile}
                onClaimStreak={handleClaimStreak}
                isProcessing={isClaimingStreak}
              />
            </div>
          )}
        </main>
      )}

      {/* 4. Footer */}
      <footer className="bg-[#141416] border-t border-[#2D2D2E] px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-[10px] font-mono text-[#8E8E93] z-10">
        <span>Ward 4 Autonomous Engineering Operations · Confidential Internal Portal</span>
        <span className="flex items-center"><ShieldCheck className="text-[#2ECC71] mr-1.5" size={12} /> Encrypted GPRS Cellular Grid Active</span>
      </footer>
      </div>
    </div>
  );
}
