export interface SensorPayload {
  sensor_id: string;
  location: {
    lat: number;
    lng: number;
    road_name: string;
  };
  timestamp: string;
  type: 'road_vibration' | 'elevation' | 'moisture' | 'photometric' | 'ultrasonic' | 'structural';
  reading: number;
  unit: string;
  threshold_breach: boolean;
  deviation_mm?: number;
  consecutive_anomalies: number;
}

export type IssuePriority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type IssueStatus = 'Reported' | 'Verified' | 'Assigned' | 'In Progress' | 'Resolved';

export interface MapMarker {
  color: string; // hex
  icon: string;  // lucide icon key
  tooltip: string;
}

export interface ProcessedIssue {
  issue_id: string;
  timestamp: string;
  source: 'sensor' | 'citizen' | 'community_verification';
  issue_type: string;
  priority: IssuePriority;
  location: {
    lat: number;
    lng: number;
    address: string;
    ward: string;
  };
  description: string;
  evidence: string[];
  credibility_score: number; // 1-10
  affected_population_estimate: number;
  recommended_action: string;
  assigned_department: string;
  resolution_sla_hours: number;
  duplicate_of: string | null;
  civic_points_awarded: number;
  map_marker: MapMarker;
  predictive_flag: boolean;
  escalation_required: boolean;
  
  // Status tracking extensions for accountability & verification
  status: IssueStatus;
  verifications_count: number;
  verified_by: string[]; // user emails or ids
  history: Array<{
    status: IssueStatus;
    timestamp: string;
    note: string;
  }>;
  eta_days?: number;
  repair_cost_estimate?: number;
}

export interface UserProfile {
  email: string;
  points: number;
  rank: 'Observer' | 'Reporter' | 'Validator' | 'Civic Champion' | 'Community Hero';
  streak: number;
  lastActive: string;
  achievements: string[];
}

export interface DepartmentMetric {
  name: string;
  active_tickets: number;
  resolved_tickets: number;
  sla_compliance: number; // percentage
  performance_score: number; // 1-100
  avg_resolution_hours: number;
}

export interface StateOfTheWardReport {
  generated_at: string;
  ward_name: string;
  summary: string;
  safety_index: number; // 0-100
  health_index: number; // 0-100
  efficiency_index: number; // 0-100
  aging_zones: Array<{
    zone: string;
    risk_factor: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
    risk_score: number;
    description: string;
  }>;
  preventive_schedule: Array<{
    target: string;
    action: string;
    cost_est: number;
    priority: string;
  }>;
}
