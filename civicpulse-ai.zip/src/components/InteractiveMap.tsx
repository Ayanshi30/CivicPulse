import React, { useState, useRef, useEffect } from "react";
import { ProcessedIssue } from "../types";
import { 
  AlertTriangle, 
  Droplet, 
  Lightbulb, 
  Trash2, 
  Activity, 
  Hammer, 
  ShieldAlert, 
  AlertOctagon, 
  MapPin, 
  Compass, 
  Layers, 
  FileText, 
  CheckCircle, 
  Users,
  TrendingUp,
  Clock
} from "lucide-react";

interface InteractiveMapProps {
  issues: ProcessedIssue[];
  selectedIssue: ProcessedIssue | null;
  onSelectIssue: (issue: ProcessedIssue) => void;
  onMapClick: (coordinates: { lat: number; lng: number; address: string }) => void;
  predictedZones: any[];
}

export default function InteractiveMap({ 
  issues, 
  selectedIssue, 
  onSelectIssue, 
  onMapClick,
  predictedZones
}: InteractiveMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredIssue, setHoveredIssue] = useState<ProcessedIssue | null>(null);
  const [mapLayer, setMapLayer] = useState<"standard" | "sensor" | "predictive">("standard");

  // Lat/Lng constraints for Ward 4
  const MIN_LAT = 40.7080;
  const MAX_LAT = 40.7240;
  const MIN_LNG = -74.0180;
  const MAX_LNG = -73.9980;

  // Convert GPS Coordinates to absolute SVG Viewbox (800x500) percentages
  const getX = (lng: number) => {
    const pct = (lng - MIN_LNG) / (MAX_LNG - MIN_LNG);
    return 50 + pct * 700; // padding of 50px left/right
  };

  const getY = (lat: number) => {
    const pct = (lat - MIN_LAT) / (MAX_LAT - MIN_LAT);
    return 450 - pct * 400; // invert Y for SVG and add padding
  };

  // Click handler to drop a pin and retrieve coordinates
  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    
    // Check if user clicked a marker button instead of the canvas background
    const target = e.target as SVGElement;
    if (target.closest('.map-marker-btn')) return;

    const rect = containerRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const pctX = (clickX / rect.width);
    const pctY = (clickY / rect.height);

    // Convert back to Lat/Lng
    const lng = MIN_LNG + pctX * (MAX_LNG - MIN_LNG);
    const lat = MAX_LAT - pctY * (MAX_LAT - MIN_LAT); // Inverted

    // Generate address guess
    const roadNames = ["Maple Ave Corridor", "Oak St Boulevard", "South St Expressway", "Pine Lane Avenue", "Metro Plaza Pavilion", "Riverfront Promenade"];
    const randomRoad = roadNames[Math.floor(Math.random() * roadNames.length)];
    const randomNum = Math.floor(10 + Math.random() * 200);
    const address = `${randomNum} ${randomRoad}, Ward 4`;

    onMapClick({ lat, lng, address });
  };

  // Helper to map Lucide keys to actual icons
  const renderMarkerIcon = (iconName: string, color: string) => {
    const size = 16;
    switch (iconName) {
      case "AlertOctagon": return <AlertOctagon size={size} style={{ color }} />;
      case "ShieldAlert": return <ShieldAlert size={size} style={{ color }} />;
      case "TriangleAlert": return <AlertTriangle size={size} style={{ color }} />;
      case "Droplets": return <Droplet size={size} style={{ color }} />;
      case "Lightbulb":
      case "LightbulbOff": return <Lightbulb size={size} style={{ color }} />;
      case "Trash": return <Trash2 size={size} style={{ color }} />;
      case "Activity": return <Activity size={size} style={{ color }} />;
      case "Hammer": return <Hammer size={size} style={{ color }} />;
      default: return <MapPin size={size} style={{ color }} />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#141416] rounded-2xl border border-[#2D2D2E] overflow-hidden relative">
      {/* Map Header Control Rail */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-[#2D2D2E] bg-[#111113] z-10">
        <div className="flex items-center space-x-3">
          <Compass className="text-[#3B82F6] animate-spin-slow" size={20} />
          <div>
            <h2 className="font-display font-semibold text-sm tracking-wide text-[#FFFFFF]">WARD 4 INFRASTRUCTURE CANVAS</h2>
            <p className="text-xs text-[#8E8E93] font-mono">Center: 40.7128° N, 74.0060° W</p>
          </div>
        </div>

        {/* View toggles */}
        <div className="flex items-center bg-[#141416] border border-[#2D2D2E] rounded-lg p-1 space-x-1">
          <button
            onClick={() => setMapLayer("standard")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition ${mapLayer === "standard" ? "bg-[#2ECC71]/20 text-[#2ECC71] border border-[#2ECC71]/30" : "text-[#8E8E93] hover:text-[#FFFFFF]"}`}
          >
            All Alerts
          </button>
          <button
            onClick={() => setMapLayer("sensor")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition ${mapLayer === "sensor" ? "bg-[#3B82F6]/20 text-[#60A5FA] border border-[#3B82F6]/30" : "text-[#8E8E93] hover:text-[#FFFFFF]"}`}
          >
            IoT Nodes
          </button>
          <button
            onClick={() => setMapLayer("predictive")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition ${mapLayer === "predictive" ? "bg-[#FFA500]/20 text-[#FFA500] border border-[#FFA500]/30" : "text-[#8E8E93] hover:text-[#FFFFFF]"}`}
          >
            Risk Heatmap
          </button>
        </div>
      </div>

      {/* SVG Container with absolute markers */}
      <div 
        ref={containerRef}
        className="relative flex-1 bg-[#111113] cursor-crosshair select-none overflow-hidden h-[450px]"
      >
        <svg 
          viewBox="0 0 800 500" 
          className="w-full h-full object-fill opacity-95 transition-opacity"
          onClick={handleSvgClick}
        >
          {/* Background Grid */}
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.03)" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="800" height="500" fill="url(#grid)" />

          {/* Waterway: Riverfront Promenade */}
          <path 
            d="M 50 0 Q 150 150 50 320 T 50 500" 
            fill="none" 
            stroke="#1d2d44" 
            strokeWidth="48" 
            opacity="0.4"
          />
          <path 
            d="M 50 0 Q 150 150 50 320 T 50 500" 
            fill="none" 
            stroke="#1e3a8a" 
            strokeWidth="8" 
            opacity="0.6"
          />

          {/* Parks & Green zones */}
          <path 
            d="M 70 80 Q 120 100 130 180 T 60 220 Z" 
            fill="rgba(16, 185, 129, 0.05)" 
            stroke="rgba(16, 185, 129, 0.15)" 
            strokeWidth="1.5"
          />
          <text x="85" y="150" fill="rgba(16, 185, 129, 0.4)" fontSize="10" fontFamily="monospace" className="select-none pointer-events-none">Riverfront Park</text>

          {/* Primary Arterial Roadways */}
          {/* West Crossing Highway */}
          <line x1="50" y1="50" x2="750" y2="450" stroke="#1f2937" strokeWidth="12" strokeLinecap="round" />
          <line x1="50" y1="50" x2="750" y2="450" stroke="#f59e0b" strokeWidth="1" strokeDasharray="5,5" strokeLinecap="round" />
          <text x="450" y="300" fill="#475569" fontSize="9" fontFamily="monospace" transform="rotate(28, 450, 300)" className="select-none pointer-events-none">WEST CROSSING HWY</text>

          {/* Oak Street */}
          <line x1="50" y1="250" x2="750" y2="250" stroke="#111827" strokeWidth="8" />
          <text x="650" y="242" fill="#475569" fontSize="9" fontFamily="monospace" className="select-none pointer-events-none">OAK ST BOULEVARD</text>

          {/* South Street */}
          <line x1="550" y1="50" x2="550" y2="450" stroke="#111827" strokeWidth="8" />
          <text x="560" y="380" fill="#475569" fontSize="9" fontFamily="monospace" transform="rotate(90, 560, 380)" className="select-none pointer-events-none">SOUTH ST CORRIDOR</text>

          {/* Pine Lane */}
          <line x1="250" y1="50" x2="250" y2="450" stroke="#111827" strokeWidth="6" />
          <text x="238" y="120" fill="#475569" fontSize="9" fontFamily="monospace" transform="rotate(-90, 238, 120)" className="select-none pointer-events-none">PINE LANE</text>

          {/* Municipal Sectors / Zones outlines */}
          <rect x="300" y="100" width="180" height="100" rx="4" fill="none" stroke="rgba(255,255,255,0.04)" strokeDasharray="3,3" />
          <text x="310" y="120" fill="rgba(255,255,255,0.2)" fontSize="10" fontFamily="monospace" className="select-none pointer-events-none">Metro Plaza Core</text>

          {/* PREDICTIVE HEATMAP LAYER */}
          {mapLayer === "predictive" && predictedZones.map((z, idx) => {
            const isCritical = z.risk_factor === "CRITICAL";
            const isHigh = z.risk_factor === "HIGH";
            let color = "rgba(234, 179, 8, 0.08)"; // Medium
            let strokeColor = "rgba(234, 179, 8, 0.2)";
            if (isCritical) {
              color = "rgba(239, 68, 68, 0.12)";
              strokeColor = "rgba(239, 68, 68, 0.35)";
            } else if (isHigh) {
              color = "rgba(249, 115, 22, 0.1)";
              strokeColor = "rgba(249, 115, 22, 0.25)";
            }

            // Draw circular warning halos around major infrastructure grids
            const hX = idx === 0 ? 350 : 250;
            const hY = idx === 0 ? 220 : 320;
            const radius = idx === 0 ? 120 : 80;

            return (
              <g key={z.zone}>
                <circle 
                  cx={hX} 
                  cy={hY} 
                  r={radius} 
                  fill={color} 
                  stroke={strokeColor} 
                  strokeWidth="2" 
                  strokeDasharray="5,3" 
                  className="animate-pulse" 
                />
                <rect x={hX - 60} y={hY - 15} width="120" height="30" rx="4" fill="#141416" stroke={strokeColor} strokeWidth="1" />
                <text x={hX} y={hY + 4} fill="#FFFFFF" fontSize="8" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  {z.risk_factor} RISK: {z.risk_score}%
                </text>
              </g>
            );
          })}
        </svg>

        {/* PIN PLACEMENT ON ACTIVE MARKERS */}
        {issues
          .filter(issue => {
            if (mapLayer === "sensor") return issue.source === "sensor";
            return true; // standard layer shows everything
          })
          .map((issue) => {
            const x = getX(issue.location.lng);
            const y = getY(issue.location.lat);
            const isSelected = selectedIssue?.issue_id === issue.issue_id;
            const isHovered = hoveredIssue?.issue_id === issue.issue_id;
            const isCritical = issue.priority === "CRITICAL";
            const isHigh = issue.priority === "HIGH";

            let pulseColor = "rgba(234, 179, 8, 0.4)"; // Medium / Low
            if (isCritical) pulseColor = "rgba(239, 68, 68, 0.6)";
            else if (isHigh) pulseColor = "rgba(249, 115, 22, 0.5)";

            return (
              <div
                key={issue.issue_id}
                style={{ left: `${x}px`, top: `${y}px` }}
                className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group"
              >
                {/* Custom Pulsing Halo for Critical and High Issues */}
                {(isCritical || isHigh) && issue.status !== "Resolved" && (
                  <div 
                    style={{ backgroundColor: pulseColor }}
                    className="absolute w-8 h-8 rounded-full -translate-x-1/4 -translate-y-1/4 animate-ping opacity-30 pointer-events-none" 
                  />
                )}

                {/* Main Interactive Button Pin */}
                <button
                  onClick={() => onSelectIssue(issue)}
                  onMouseEnter={() => setHoveredIssue(issue)}
                  onMouseLeave={() => setHoveredIssue(null)}
                  className={`map-marker-btn w-6 h-6 rounded-full flex items-center justify-center transition shadow-lg ${
                    isSelected 
                      ? "bg-white scale-125 border-2 border-[#141416] ring-4 ring-[#3B82F6]/40" 
                      : "bg-[#111113] hover:scale-110 hover:bg-[#1C1C1E]"
                  }`}
                  style={{ border: `1.5px solid ${issue.map_marker.color}` }}
                >
                  {renderMarkerIcon(issue.map_marker.icon, issue.map_marker.color)}
                </button>

                {/* Small Status indicator tag */}
                <div 
                  className="absolute w-2 h-2 rounded-full border border-[#111113] -bottom-0.5 -right-0.5 shadow"
                  style={{
                    backgroundColor: 
                      issue.status === "Resolved" ? "#2ECC71" :
                      issue.status === "In Progress" ? "#3B82F6" :
                      issue.status === "Assigned" ? "#A855F7" :
                      issue.status === "Verified" ? "#06B6D4" : "#8E8E93"
                  }}
                />
              </div>
            );
          })}

        {/* Hover Tooltip Overlay */}
        {(hoveredIssue || selectedIssue) && (
          <div className="absolute bottom-4 left-4 bg-[#141416]/95 border border-[#2D2D2E] p-4 rounded-xl shadow-2xl max-w-xs z-30 transition-all glow-card">
            {hoveredIssue ? (
              <div>
                <div className="flex items-center space-x-2">
                  <span className={`w-2.5 h-2.5 rounded-full`} style={{ backgroundColor: hoveredIssue.map_marker.color }} />
                  <span className="font-mono text-[10px] font-bold text-[#8E8E93] uppercase tracking-widest">{hoveredIssue.source} Payload</span>
                </div>
                <h4 className="font-display font-medium text-xs text-white capitalize mt-1">{hoveredIssue.issue_type}</h4>
                <p className="text-[11px] text-[#8E8E93] mt-1 line-clamp-2">{hoveredIssue.description}</p>
                <div className="flex items-center justify-between mt-2.5 font-mono text-[10px] border-t border-[#2D2D2E] pt-2 text-[#8E8E93]">
                  <span className="flex items-center"><Users size={10} className="mr-1"/> Pop: ~{hoveredIssue.affected_population_estimate}</span>
                  <span className={`px-1.5 py-0.5 rounded font-bold text-[9px] ${
                    hoveredIssue.priority === 'CRITICAL' ? 'bg-[#FF4B2B]/10 text-[#FF4B2B]' :
                    hoveredIssue.priority === 'HIGH' ? 'bg-[#FFA500]/10 text-[#FFA500]' : 'bg-[#1C1C1E] text-[#8E8E93]'
                  }`}>
                    {hoveredIssue.priority}
                  </span>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center space-x-2">
                  <span className={`w-2.5 h-2.5 rounded-full`} style={{ backgroundColor: selectedIssue!.map_marker.color }} />
                  <span className="font-mono text-[10px] font-bold text-[#3B82F6] uppercase tracking-widest">Selected Alert</span>
                </div>
                <h4 className="font-display font-medium text-xs text-white capitalize mt-1">{selectedIssue!.issue_type}</h4>
                <p className="text-[10px] text-[#8E8E93] font-mono mt-0.5">{selectedIssue!.location.address}</p>
                <div className="flex items-center justify-between mt-2.5 font-mono text-[10px] border-t border-[#2D2D2E] pt-2 text-[#8E8E93]">
                  <span className="flex items-center"><Clock size={10} className="mr-1"/> SLA: {selectedIssue!.resolution_sla_hours} hrs</span>
                  <span className="text-[#2ECC71]">{selectedIssue!.status}</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Map Help Overlay */}
        <div className="absolute top-4 left-4 bg-[#141416]/90 border border-[#2D2D2E] px-3 py-2 rounded-lg font-mono text-[9px] text-[#8E8E93] flex flex-col space-y-1 select-none pointer-events-none">
          <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#FF4B2B] mr-2" /> Critical (&lt;2h SLA)</div>
          <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#FFA500] mr-2" /> High (&lt;24h SLA)</div>
          <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#FFD700] mr-2" /> Medium (&lt;72h SLA)</div>
          <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#2ECC71] mr-2" /> Low (&lt;7d SLA)</div>
          <div className="pt-1.5 border-t border-[#2D2D2E] text-[#3B82F6] font-bold">🎯 Click map to report pin</div>
        </div>
      </div>
    </div>
  );
}
