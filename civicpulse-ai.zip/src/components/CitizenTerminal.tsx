import { useState } from "react";
import { 
  Megaphone, 
  Sparkles, 
  MapPin, 
  Camera, 
  HelpCircle, 
  AlertTriangle,
  Gift,
  RefreshCw,
  Search
} from "lucide-react";

interface CitizenTerminalProps {
  onSubmitReport: (text: string, coordinates: { lat: number; lng: number; address: string } | null, imageIncluded: boolean) => Promise<any>;
  isProcessing: boolean;
  mapClickedCoords: { lat: number; lng: number; address: string } | null;
  onClearCoords: () => void;
}

export default function CitizenTerminal({ 
  onSubmitReport, 
  isProcessing, 
  mapClickedCoords,
  onClearCoords
}: CitizenTerminalProps) {
  const [reportText, setReportText] = useState<string>("");
  const [imageIncluded, setImageIncluded] = useState<boolean>(false);
  const [showTaxonomy, setShowTaxonomy] = useState<boolean>(false);

  const sampleCitizenInputs = [
    "A massive, deep pothole has opened up on Maple Street near the crossing. It's filled with water and several cars have hit it hard already. Someone's going to pop a tire!",
    "Streetlight number 45 on Oak Boulevard is completely dead, making the entire sidewalk pitched black. There was a suspicious character loitering there last night.",
    "Someone dumped an old mattress and three heavy trash bags on the sidewalk of Riverfront promenade. It's blocking the wheelchair ramp.",
    "Water is shooting up from the sidewalk near the fire hydrant on South Street! Looks like a water main pipe cracked underneath, the whole corner is starting to waterlog."
  ];

  const handleUseSampleText = (text: string) => {
    setReportText(text);
  };

  const handleSubmit = async () => {
    if (!reportText.trim()) {
      alert("Please provide some description of the issue.");
      return;
    }
    const result = await onSubmitReport(reportText, mapClickedCoords, imageIncluded);
    if (result && result.success) {
      setReportText("");
      setImageIncluded(false);
      onClearCoords();
    }
  };

  return (
    <div className="flex flex-col bg-[#141416] rounded-2xl border border-[#2D2D2E] p-6 h-full relative">
      <div className="flex items-center space-x-3 pb-4 border-b border-[#2D2D2E]">
        <Megaphone className="text-[#2ECC71] animate-pulse" size={20} />
        <div>
          <h3 className="font-display font-semibold text-sm text-white">CITIZEN ENGAGEMENT HUB</h3>
          <p className="text-[11px] text-[#8E8E93]">Pillar 2: Log unstructured reports parsed instantly by AI</p>
        </div>
      </div>

      {/* Selected map position banner */}
      {mapClickedCoords ? (
        <div className="mt-4 bg-[#2ECC71]/10 border border-[#2ECC71]/20 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <MapPin className="text-[#2ECC71] animate-bounce" size={16} />
            <div>
              <p className="text-[10px] font-bold text-[#2ECC71] uppercase tracking-wider font-mono">Pin Attached</p>
              <p className="text-xs text-slate-300 font-mono truncate max-w-[180px]">{mapClickedCoords.address}</p>
            </div>
          </div>
          <button 
            onClick={onClearCoords}
            className="text-[10px] text-[#8E8E93] hover:text-[#FFFFFF] underline font-mono cursor-pointer"
          >
            Reset Pin
          </button>
        </div>
      ) : (
        <div className="mt-4 bg-[#0A0A0B]/40 border border-dashed border-[#2D2D2E] rounded-xl p-3 text-center text-[11px] text-[#8E8E93] font-mono">
          💡 Click anywhere on the map to anchor a specific GPS coordinate pin.
        </div>
      )}

      {/* Unstructured Text Input Area */}
      <div className="mt-4">
        <label className="text-xs font-semibold text-[#8E8E93] block mb-1.5 font-mono">What infrastructure hazard did you observe?</label>
        <textarea
          value={reportText}
          onChange={(e) => setReportText(e.target.value)}
          placeholder="Describe the problem, location details, water depth, dark streets, active damage, etc..."
          className="w-full bg-[#0A0A0B] border border-[#2D2D2E] rounded-xl p-3 text-xs text-[#E0E0E0] focus:outline-none focus:ring-1 focus:ring-[#2ECC71]/50 resize-none h-[110px]"
          spellCheck="false"
        />
      </div>

      {/* Quick sample suggestions for testing */}
      <div className="mt-3">
        <span className="text-[10px] font-mono text-[#8E8E93] block mb-1.5">💡 Quick Test Scenarios (Click to Load):</span>
        <div className="flex flex-col space-y-1">
          {sampleCitizenInputs.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => handleUseSampleText(sample)}
              className="text-left text-[10px] text-[#8E8E93] hover:text-[#2ECC71] hover:bg-[#1C1C1E] p-1.5 rounded border border-[#2D2D2E] transition truncate cursor-pointer"
            >
              {sample}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive attachment options */}
      <div className="mt-4 flex items-center justify-between border-t border-[#2D2D2E] pt-3">
        <label className="flex items-center space-x-2.5 cursor-pointer group">
          <input
            type="checkbox"
            checked={imageIncluded}
            onChange={(e) => setImageIncluded(e.target.checked)}
            className="rounded border-[#2D2D2E] bg-[#0A0A0B] text-[#2ECC71] focus:ring-0 w-4 h-4 transition"
          />
          <div className="flex items-center space-x-1">
            <Camera size={14} className={`group-hover:text-[#2ECC71] transition ${imageIncluded ? 'text-[#2ECC71]' : 'text-[#8E8E93]'}`} />
            <span className="text-[11px] font-medium text-[#8E8E93] group-hover:text-slate-200">Simulate Photo Attachment (+20 pts)</span>
          </div>
        </label>

        <button
          onClick={() => setShowTaxonomy(!showTaxonomy)}
          className="text-[10px] text-[#8E8E93] hover:text-slate-200 flex items-center space-x-1 font-mono cursor-pointer"
        >
          <HelpCircle size={12} />
          <span>View Taxonomy</span>
        </button>
      </div>

      {/* Custom taxonomy collapse */}
      {showTaxonomy && (
        <div className="mt-3 bg-[#111113] border border-[#2D2D2E] rounded-lg p-3 text-[10px] font-mono text-[#8E8E93] space-y-1 animate-fade-in">
          <p className="text-white font-bold border-b border-[#2D2D2E] pb-1 mb-1 text-[11px]">Valid AI Taxonomy:</p>
          <p><span className="text-[#2ECC71]">Road:</span> pothole, crack, uneven, marking fade, sinkholes</p>
          <p><span className="text-[#2ECC71]">Water:</span> leakage, flooding, blocked drain, broken pipe</p>
          <p><span className="text-[#2ECC71]">Electricity:</span> streetlight outage, exposed wiring</p>
          <p><span className="text-[#2ECC71]">Waste:</span> overflowing bin, illegal dumping</p>
          <p><span className="text-[#2ECC71]">Structure:</span> damaged bridge, broken railing, wall collapse</p>
        </div>
      )}

      {/* Process with AI Button */}
      <button
        onClick={handleSubmit}
        disabled={isProcessing}
        className="mt-4 w-full bg-[#2ECC71] hover:bg-[#2ECC71]/90 disabled:bg-[#2D2D2E] text-white py-2.5 rounded-xl text-xs font-semibold font-mono tracking-wider flex items-center justify-center transition cursor-pointer"
      >
        {isProcessing ? (
          <>
            <RefreshCw className="animate-spin mr-2" size={14} />
            AI PROCESSING REPORT...
          </>
        ) : (
          <>
            <Sparkles className="mr-2" size={14} />
            PROCESS WITH AI CORE
          </>
        )}
      </button>

      {/* Points Ledger Guide */}
      <div className="mt-3 flex items-center justify-between text-[9px] font-mono text-[#8E8E93] border-t border-[#2D2D2E] pt-3">
        <span className="flex items-center"><Gift size={10} className="mr-1 text-[#2ECC71]" /> Report: +10 pts</span>
        <span>+ Photo: +20 pts</span>
        <span>Verified: +30 pts</span>
      </div>
    </div>
  );
}
