import { useState } from "react";
import { SensorPayload } from "../types";
import { 
  Cpu, 
  Send, 
  RefreshCw, 
  Activity, 
  Ruler, 
  Droplet, 
  Lightbulb, 
  Trash2, 
  Zap, 
  ShieldAlert 
} from "lucide-react";

interface IoTTerminalProps {
  onTransmitSignal: (payload: SensorPayload) => Promise<void>;
  isProcessing: boolean;
}

export default function IoTTerminal({ onTransmitSignal, isProcessing }: IoTTerminalProps) {
  const [activeTemplate, setActiveTemplate] = useState<string>("road_vibration");
  const [customPayload, setCustomPayload] = useState<string>("");

  // Raw templates in alignment with Pillar 1 definitions
  const templates: Record<string, SensorPayload> = {
    road_vibration: {
      sensor_id: "VIB-904",
      location: { lat: 40.7165, lng: -74.0028, road_name: "Maple Ave Corridor, Grid 3C" },
      timestamp: new Date().toISOString(),
      type: "road_vibration",
      reading: 4.8,
      unit: "G-force delta",
      threshold_breach: true,
      deviation_mm: 32,
      consecutive_anomalies: 8
    },
    elevation: {
      sensor_id: "ELEV-204",
      location: { lat: 40.7212, lng: -74.0125, road_name: "Pine Lane Bicycle Lane, Grid 1A" },
      timestamp: new Date().toISOString(),
      type: "elevation",
      reading: 3.1, // 3.1 cm deviation (> 2.5cm threshold)
      unit: "cm elevation delta",
      threshold_breach: true,
      deviation_mm: 31,
      consecutive_anomalies: 4
    },
    moisture: {
      sensor_id: "MOIST-802",
      location: { lat: 40.7142, lng: -74.0118, road_name: "South Street Low-lying Catch Basin, Grid 2F" },
      timestamp: new Date().toISOString(),
      type: "moisture",
      reading: 88.5,
      unit: "relative moisture %",
      threshold_breach: true,
      consecutive_anomalies: 7
    },
    photometric: {
      sensor_id: "PHOTO-112",
      location: { lat: 40.7122, lng: -74.0085, road_name: "Commercial District Corridor Streetlight, Grid 2C" },
      timestamp: new Date().toISOString(),
      type: "photometric",
      reading: 0.08,
      unit: "lux illuminance",
      threshold_breach: true,
      consecutive_anomalies: 12
    },
    ultrasonic: {
      sensor_id: "ULTRA-304",
      location: { lat: 40.7092, lng: -74.0035, road_name: "Metro Plaza Trash Bin, Grid 5B" },
      timestamp: new Date().toISOString(),
      type: "ultrasonic",
      reading: 96.0,
      unit: "% volume fill level",
      threshold_breach: true,
      consecutive_anomalies: 3
    },
    structural: {
      sensor_id: "STRUCT-704",
      location: { lat: 40.7152, lng: -74.0158, road_name: "West Crossing Highway Bridge expansion joint, Grid 4A" },
      timestamp: new Date().toISOString(),
      type: "structural",
      reading: 1.48,
      unit: "strain deflection ratio",
      threshold_breach: true,
      consecutive_anomalies: 15
    }
  };

  // Set initial text template
  useState(() => {
    setCustomPayload(JSON.stringify(templates.road_vibration, null, 2));
  });

  const handleTemplateSelection = (key: string) => {
    setActiveTemplate(key);
    // Update timestamp before loading
    const updated = { ...templates[key], timestamp: new Date().toISOString() };
    setCustomPayload(JSON.stringify(updated, null, 2));
  };

  const handleTransmit = async () => {
    try {
      const parsed = JSON.parse(customPayload);
      await onTransmitSignal(parsed);
    } catch (e) {
      alert("Malformed JSON payload structure. Please verify correct formatting.");
    }
  };

  const renderTemplateIcon = (key: string) => {
    switch (key) {
      case "road_vibration": return <Activity size={14} className="text-[#FF4B2B]" />;
      case "elevation": return <Ruler size={14} className="text-[#FFA500]" />;
      case "moisture": return <Droplet size={14} className="text-[#60A5FA]" />;
      case "photometric": return <Lightbulb size={14} className="text-[#FFD700]" />;
      case "ultrasonic": return <Trash2 size={14} className="text-[#A855F7]" />;
      case "structural": return <ShieldAlert size={14} className="text-[#FF4B2B]" />;
      default: return <Cpu size={14} />;
    }
  };

  return (
    <div className="flex flex-col bg-[#141416] rounded-2xl border border-[#2D2D2E] p-6 h-full relative">
      <div className="flex items-center space-x-3 pb-4 border-b border-[#2D2D2E]">
        <Cpu className="text-[#3B82F6] animate-pulse" size={20} />
        <div>
          <h3 className="font-display font-semibold text-sm text-white">HARDWARE SENSOR CONTROLLER</h3>
          <p className="text-[11px] text-[#8E8E93]">Pillar 1: Simulate IoT-embedded edge telemetry signals</p>
        </div>
      </div>

      {/* Select Sensor Payload Templates */}
      <div className="grid grid-cols-3 gap-2 mt-4">
        {Object.keys(templates).map((key) => (
          <button
            key={key}
            onClick={() => handleTemplateSelection(key)}
            className={`flex items-center space-x-1.5 px-2.5 py-2 rounded-lg text-[10px] font-medium font-mono border transition ${
              activeTemplate === key 
                ? "bg-[#1C1C1E] border-[#3B82F6]/50 text-[#60A5FA]" 
                : "bg-[#111113]/60 border-[#2D2D2E] text-[#8E8E93] hover:text-[#FFFFFF] hover:border-[#8E8E93]/40"
            }`}
          >
            {renderTemplateIcon(key)}
            <span className="capitalize">{key.replace("_", " ")}</span>
          </button>
        ))}
      </div>

      {/* Live Code/JSON Editor */}
      <div className="flex-1 mt-4 flex flex-col min-h-[180px]">
        <div className="flex items-center justify-between px-3 py-1.5 bg-[#0A0A0B] border-t border-x border-[#2D2D2E] rounded-t-lg font-mono text-[10px] text-[#8E8E93]">
          <span>payload_stream.json</span>
          <span className="text-[#2ECC71] flex items-center"><Zap size={10} className="mr-1"/> telemetry active</span>
        </div>
        <textarea
          value={customPayload}
          onChange={(e) => setCustomPayload(e.target.value)}
          className="flex-1 w-full bg-[#0A0A0B] border border-[#2D2D2E] rounded-b-lg p-3 font-mono text-xs text-[#E0E0E0] focus:outline-none focus:ring-1 focus:ring-[#3B82F6]/50 resize-none"
          spellCheck="false"
        />
      </div>

      {/* Trigger button */}
      <button
        onClick={handleTransmit}
        disabled={isProcessing}
        className="mt-4 w-full bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] hover:opacity-90 disabled:bg-[#2D2D2E] text-white py-2.5 rounded-xl text-xs font-semibold font-mono tracking-wider flex items-center justify-center transition cursor-pointer"
      >
        {isProcessing ? (
          <>
            <RefreshCw className="animate-spin mr-2" size={14} />
            AI PARSING TELEMETRY...
          </>
        ) : (
          <>
            <Send className="mr-2" size={14} />
            TRANSMIT SENSOR SIGNAL
          </>
        )}
      </button>

      {/* Signal metadata footer info */}
      <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-[#8E8E93] bg-[#111113] px-3 py-2 rounded-lg border border-[#2D2D2E]/40">
        <span>Channel: GPRS-Secured-4G</span>
        <span>Freq: 868 MHz</span>
      </div>
    </div>
  );
}
