import { UserProfile } from "../types";
import { 
  Trophy, 
  Award, 
  Flame, 
  TrendingUp, 
  ChevronRight, 
  CheckCircle,
  HelpCircle,
  Coins
} from "lucide-react";

interface CitizenLeaderboardProps {
  profile: UserProfile;
  onClaimStreak: () => Promise<void>;
  isProcessing: boolean;
}

export default function CitizenLeaderboard({ profile, onClaimStreak, isProcessing }: CitizenLeaderboardProps) {
  // Compute points remaining to unlock next rank
  const rankRequirements: Record<string, { next: string; target: number }> = {
    Observer: { next: "Reporter", target: 50 },
    Reporter: { next: "Validator", target: 100 },
    Validator: { next: "Civic Champion", target: 200 },
    "Civic Champion": { next: "Community Hero", target: 300 },
    "Community Hero": { next: "Max Rank Achieved", target: 300 }
  };

  const currentRankInfo = rankRequirements[profile.rank] || { next: "Max Rank", target: 300 };
  const pointsProgress = Math.min(100, Math.round((profile.points / currentRankInfo.target) * 100));

  // Predefined lists of achievements
  const achievementBadges: Record<string, { desc: string; icon: string; color: string }> = {
    "First Alert": { desc: "Report your first municipal infrastructure incident.", icon: "🎯", color: "from-blue-500/20 to-indigo-500/10" },
    "Camera Eye": { desc: "Upload detailed photo evidence with a hazard report.", icon: "📸", color: "from-emerald-500/20 to-teal-500/10" },
    "Street Guardian": { desc: "Contribute reports that are verified by 3+ neighbors.", icon: "🛡️", color: "from-purple-500/20 to-fuchsia-500/10" },
    "Streak Master": { desc: "Maintain a 7-day consecutive active civic streak.", icon: "🔥", color: "from-orange-500/20 to-amber-500/10" },
    "Solver": { desc: "Original reported issue is successfully repaired.", icon: "🛠️", color: "from-cyan-500/20 to-blue-500/10" },
    "Validator Star": { desc: "Successfully verify 5 peer reports.", icon: "⭐", color: "from-yellow-500/20 to-amber-500/10" }
  };

  return (
    <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-6 h-full flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex items-center space-x-2.5 pb-4 border-b border-[#2D2D2E] mb-4">
          <Trophy className="text-[#FFD700] animate-bounce" size={18} />
          <div>
            <h3 className="font-display font-semibold text-sm text-white">CITIZEN CIVIC LEDGER</h3>
            <p className="text-[10px] text-[#8E8E93] font-mono">Gamified rewards for community-led inspections</p>
          </div>
        </div>

        {/* User Card */}
        <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] block uppercase">Rank Status</span>
            <span className="font-display font-bold text-lg text-[#FFD700] tracking-wide flex items-center mt-0.5">
              <Award className="mr-1 text-[#FFD700]" size={16} />
              {profile.rank}
            </span>
            <span className="text-xs text-[#8E8E93] block mt-1 font-mono">{profile.email}</span>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] block uppercase">Civic Balance</span>
            <span className="text-2xl font-display font-black text-white tracking-tight flex items-center justify-end mt-0.5">
              <Coins className="text-[#FFD700] mr-1.5" size={18} />
              {profile.points}
            </span>
            <span className="text-[10px] text-[#8E8E93] font-mono">pts</span>
          </div>
        </div>

        {/* Rank Progression Bar */}
        {profile.rank !== "Community Hero" && (
          <div className="mt-4 bg-[#111113] border border-[#2D2D2E] rounded-xl p-3.5">
            <div className="flex justify-between items-center text-[11px] font-mono text-[#8E8E93] mb-1.5">
              <span>Progress to <strong className="text-white font-medium">{currentRankInfo.next}</strong></span>
              <span>{profile.points} / {currentRankInfo.target} pts</span>
            </div>
            <div className="w-full bg-[#2D2D2E] rounded-full h-2 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-[#FFA500] to-[#FFD700] h-full rounded-full transition-all duration-500"
                style={{ width: `${pointsProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Activity Streak */}
        <div className="mt-4 bg-gradient-to-r from-[#FFA500]/5 to-[#FFD700]/5 border border-[#FFA500]/10 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="bg-[#FFA500]/10 p-2 rounded-xl border border-[#FFA500]/20">
              <Flame className="text-[#FFA500] animate-pulse" size={18} />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">7-Day Civic Active Streak</h4>
              <p className="text-[10px] text-[#8E8E93] font-mono">Log consecutive inspections to earn +100 bonus pts</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 justify-between md:justify-end">
            <div className="flex space-x-1">
              {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                <div 
                  key={day}
                  className={`w-4 h-4 rounded-full flex items-center justify-center font-mono text-[9px] font-bold ${
                    profile.streak >= day 
                      ? "bg-[#FFA500] text-white shadow shadow-[#FFA500]/20" 
                      : "bg-[#111113] border border-[#2D2D2E] text-[#8E8E93]"
                  }`}
                >
                  {day}
                </div>
              ))}
            </div>

            {profile.streak >= 7 && (
              <button
                onClick={onClaimStreak}
                disabled={isProcessing}
                className="bg-[#FFA500] hover:bg-[#FFA500]/90 text-white font-mono font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition animate-pulse cursor-pointer"
              >
                CLAIM +100
              </button>
            )}
          </div>
        </div>

        {/* Achievements / Badges Grid */}
        <div className="mt-5">
          <h4 className="text-xs font-semibold text-[#8E8E93] mb-3 font-mono">INSIGNIA & ACHIEVEMENTS</h4>
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(achievementBadges).map(([title, item]) => {
              const isUnlocked = profile.achievements.includes(title);
              return (
                <div 
                  key={title}
                  className={`border rounded-xl p-3 flex flex-col justify-between transition-all relative overflow-hidden ${
                    isUnlocked 
                      ? `bg-gradient-to-br ${item.color} border-[#2D2D2E] opacity-100` 
                      : "bg-[#0A0A0B]/30 border-[#2D2D2E] opacity-40"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-lg">{item.icon}</span>
                    {isUnlocked && <CheckCircle size={10} className="text-[#2ECC71]" />}
                  </div>
                  <div className="mt-2">
                    <p className="text-xs font-bold text-white">{title}</p>
                    <p className="text-[9px] text-[#8E8E93] leading-tight mt-0.5">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-[#2D2D2E] font-mono text-[9px] text-[#8E8E93] text-center">
        Accountability Ledger ID: SEC-LGR-{profile.email.toUpperCase().slice(0, 5)}
      </div>
    </div>
  );
}
