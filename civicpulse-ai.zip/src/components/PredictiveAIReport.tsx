import { useState, useEffect } from "react";
import { StateOfTheWardReport } from "../types";
import { 
  Sparkles, 
  RefreshCw, 
  Activity, 
  MapPin, 
  TrendingUp, 
  AlertOctagon, 
  Coins, 
  FileCheck,
  Zap,
  ShieldCheck,
  Heart,
  Settings,
  ShieldAlert
} from "lucide-react";

interface PredictiveAIReportProps {
  onGenerateReport: () => Promise<StateOfTheWardReport | null>;
  isGenerating: boolean;
  savedReport: StateOfTheWardReport | null;
}

export default function PredictiveAIReport({ 
  onGenerateReport, 
  isGenerating, 
  savedReport 
}: PredictiveAIReportProps) {
  const [report, setReport] = useState<StateOfTheWardReport | null>(savedReport);

  useEffect(() => {
    if (savedReport) {
      setReport(savedReport);
    }
  }, [savedReport]);

  const handleTriggerReport = async () => {
    const freshReport = await onGenerateReport();
    if (freshReport) {
      setReport(freshReport);
    }
  };

  return (
    <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-6 h-full flex flex-col justify-between">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#2D2D2E] mb-4">
          <div className="flex items-center space-x-2.5">
            <Sparkles className="text-[#60A5FA] animate-pulse" size={18} />
            <div>
              <h3 className="font-display font-semibold text-sm text-white">PREDICTIVE & OPERATIONAL AI</h3>
              <p className="text-[10px] text-[#8E8E93] font-mono">Pillar 3: Predictive hazard schedules & risk maps</p>
            </div>
          </div>

          <button
            onClick={handleTriggerReport}
            disabled={isGenerating}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 text-[10px] font-mono font-bold text-[#60A5FA] hover:text-white bg-[#3B82F6]/10 hover:bg-[#3B82F6]/20 rounded-lg border border-[#3B82F6]/20 transition disabled:opacity-50 cursor-pointer"
          >
            {isGenerating ? <RefreshCw className="animate-spin" size={11} /> : <Zap size={11} />}
            <span>{report ? "RE-RUN AI" : "GENERATE STATE OF WARD"}</span>
          </button>
        </div>

        {report ? (
          <div className="space-y-4 animate-fade-in">
            {/* Index Grid */}
            <div className="grid grid-cols-3 gap-3">
              {/* Safety Index */}
              <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 text-center">
                <span className="text-[9px] font-mono font-bold text-[#8E8E93] block uppercase">Public Safety</span>
                <span className="text-lg font-display font-bold text-[#2ECC71] block mt-0.5">{report.safety_index}%</span>
                <div className="w-full bg-[#2D2D2E] rounded-full h-1 mt-1.5 overflow-hidden">
                  <div className="bg-[#2ECC71] h-full rounded-full" style={{ width: `${report.safety_index}%` }} />
                </div>
              </div>

              {/* Health Index */}
              <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 text-center">
                <span className="text-[9px] font-mono font-bold text-[#8E8E93] block uppercase">Sanit. & Health</span>
                <span className="text-lg font-display font-bold text-[#60A5FA] block mt-0.5">{report.health_index}%</span>
                <div className="w-full bg-[#2D2D2E] rounded-full h-1 mt-1.5 overflow-hidden">
                  <div className="bg-[#3B82F6] h-full rounded-full" style={{ width: `${report.health_index}%` }} />
                </div>
              </div>

              {/* Response Efficiency Index */}
              <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 text-center">
                <span className="text-[9px] font-mono font-bold text-[#8E8E93] block uppercase">Work Efficiency</span>
                <span className="text-lg font-display font-bold text-[#60A5FA] block mt-0.5">{report.efficiency_index}%</span>
                <div className="w-full bg-[#2D2D2E] rounded-full h-1 mt-1.5 overflow-hidden">
                  <div className="bg-[#3B82F6] h-full rounded-full" style={{ width: `${report.efficiency_index}%` }} />
                </div>
              </div>
            </div>

            {/* Executive Summary */}
            <div className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3.5">
              <span className="text-[9px] font-mono font-bold text-[#60A5FA] block uppercase tracking-widest mb-1.5 flex items-center">
                <FileCheck className="mr-1" size={11} /> Weekly State of the Ward AI Summary
              </span>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">{report.summary}</p>
            </div>

            {/* Aging zones / risk vectors */}
            <div>
              <span className="text-[10px] font-mono font-bold text-[#8E8E93] block mb-2 tracking-wide uppercase">Zone Fatigue & Aging Index</span>
              <div className="space-y-2">
                {report.aging_zones.map((zone) => {
                  const isCritical = zone.risk_factor === "CRITICAL";
                  const isHigh = zone.risk_factor === "HIGH";

                  return (
                    <div 
                      key={zone.zone}
                      className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 flex items-start justify-between gap-3 hover:border-[#3B82F6]/40 transition"
                    >
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className={`w-2 h-2 rounded-full ${
                            isCritical ? "bg-[#FF4B2B] animate-ping" : isHigh ? "bg-[#FFA500]" : "bg-[#FFD700]"
                          }`} />
                          <h4 className="text-xs font-bold text-slate-300">{zone.zone}</h4>
                        </div>
                        <p className="text-[10px] text-[#8E8E93] mt-1 leading-relaxed">{zone.description}</p>
                      </div>

                      <div className="text-right">
                        <span className={`px-1.5 py-0.5 rounded font-mono font-bold text-[9px] ${
                          isCritical ? "bg-[#FF4B2B]/10 text-[#FF4B2B] border border-[#FF4B2B]/20" : 
                          isHigh ? "bg-[#FFA500]/10 text-[#FFA500] border border-[#FFA500]/20" : 
                          "bg-[#FFD700]/10 text-[#FFD700] border border-[#FFD700]/20"
                        }`}>
                          {zone.risk_factor} RISK: {zone.risk_score}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Costed Preventive maintenance schedule */}
            <div>
              <span className="text-[10px] font-mono font-bold text-[#8E8E93] block mb-2 tracking-wide uppercase">Preventive Maintenance Schedule</span>
              <div className="space-y-2">
                {report.preventive_schedule.map((sch) => (
                  <div 
                    key={sch.target}
                    className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-3 flex items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-300">{sch.target}</h4>
                      <p className="text-[10px] text-[#8E8E93] mt-0.5">{sch.action}</p>
                    </div>

                    <div className="text-right font-mono flex flex-col items-end">
                      <span className="text-[#2ECC71] font-bold text-xs flex items-center">
                        <Coins size={10} className="mr-1" />
                        ${sch.cost_est.toLocaleString()}
                      </span>
                      <span className={`text-[8px] font-bold px-1 rounded mt-1 ${
                        sch.priority === "HIGH" ? "bg-[#FF4B2B]/10 text-[#FF4B2B]" : "bg-[#1C1C1E] text-[#8E8E93]"
                      }`}>
                        {sch.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Empty Report State */
          <div className="flex-1 flex flex-col items-center justify-center text-center py-12 border border-dashed border-[#2D2D2E] rounded-2xl bg-[#111113]/30">
            <ShieldCheck className="text-[#8E8E93]/60 mb-3" size={32} />
            <h4 className="text-xs font-bold text-[#8E8E93] font-mono">No Report Compiled Yet</h4>
            <p className="text-[11px] text-[#8E8E93] max-w-xs mt-1 leading-relaxed">
              Click "Generate State of Ward" in the header to synthesize historical and active infrastructure signals into a weekly predictive maintenance assessment using Gemini.
            </p>
          </div>
        )}
      </div>

      {report && (
        <div className="mt-4 pt-3 border-t border-[#2D2D2E] text-[10px] font-mono text-[#8E8E93] flex justify-between">
          <span>COMPILED FOR: WARD 4 OPERATIONS</span>
          <span>DATE: {new Date(report.generated_at || Date.now()).toLocaleDateString()}</span>
        </div>
      )}
    </div>
  );
}
