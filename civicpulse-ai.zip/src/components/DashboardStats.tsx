import { DepartmentMetric } from "../types";
import { 
  Building2, 
  CheckCircle, 
  Clock, 
  BarChart2, 
  TrendingUp, 
  AlertTriangle,
  SunDim,
  Gauge
} from "lucide-react";

interface DashboardStatsProps {
  departments: DepartmentMetric[];
  activeCount: number;
  resolvedCount: number;
}

export default function DashboardStats({ departments, activeCount, resolvedCount }: DashboardStatsProps) {
  // Compute overall municipal SLA
  const averageSLA = Math.round(
    departments.reduce((acc, curr) => acc + curr.sla_compliance, 0) / departments.length
  );

  return (
    <div className="space-y-6">
      {/* Top Level Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Alerts */}
        <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] uppercase tracking-widest">Active Haz-Alerts</span>
            <h4 className="text-2xl font-display font-semibold text-white mt-1">{activeCount}</h4>
          </div>
          <div className="bg-[#FF4B2B]/10 p-2.5 rounded-xl border border-[#FF4B2B]/20">
            <AlertTriangle className="text-[#FF4B2B]" size={20} />
          </div>
        </div>

        {/* Resolved Work Orders */}
        <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] uppercase tracking-widest">Resolved Repairs</span>
            <h4 className="text-2xl font-display font-semibold text-[#2ECC71] mt-1">+{resolvedCount}</h4>
          </div>
          <div className="bg-[#2ECC71]/10 p-2.5 rounded-xl border border-[#2ECC71]/20">
            <CheckCircle className="text-[#2ECC71]" size={20} />
          </div>
        </div>

        {/* General SLA Level */}
        <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] uppercase tracking-widest">SLA Compliance</span>
            <h4 className="text-2xl font-display font-semibold text-[#3B82F6] mt-1">{averageSLA}%</h4>
          </div>
          <div className="bg-[#3B82F6]/10 p-2.5 rounded-xl border border-[#3B82F6]/20">
            <Gauge className="text-[#3B82F6]" size={20} />
          </div>
        </div>

        {/* METEOROLOGICAL / AMBIENT CLIMATE CARD */}
        <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold text-[#8E8E93] uppercase tracking-widest">Meteorology Risk</span>
            <h4 className="text-2xl font-display font-semibold text-[#FFA500] mt-1">MODERATE</h4>
          </div>
          <div className="bg-[#FFA500]/10 p-2.5 rounded-xl border border-[#FFA500]/20">
            <SunDim className="text-[#FFA500] animate-spin-slow" size={20} />
          </div>
        </div>
      </div>

      {/* Department Performance Board */}
      <div className="bg-[#141416] border border-[#2D2D2E] rounded-2xl p-6">
        <div className="flex items-center space-x-2.5 pb-4 border-b border-[#2D2D2E] mb-4">
          <Building2 className="text-[#60A5FA]" size={18} />
          <div>
            <h3 className="font-display font-semibold text-sm text-white">DEPARTMENT PERFORMANCE & TRANSPARENCY</h3>
            <p className="text-[10px] text-[#8E8E93] font-mono">Resolutions, SLA indices, and response velocities</p>
          </div>
        </div>

        {/* Table/List of departments */}
        <div className="space-y-4">
          {departments.map((dept) => {
            const isHighSla = dept.sla_compliance >= 90;
            const isLowSla = dept.sla_compliance < 85;

            return (
              <div 
                key={dept.name} 
                className="bg-[#111113] border border-[#2D2D2E] rounded-xl p-4 hover:border-[#3B82F6]/40 transition"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                  {/* Dept Name & Workload */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between md:justify-start md:space-x-4">
                      <span className="font-display font-medium text-sm text-white">{dept.name}</span>
                      <span className="bg-[#1C1C1E] text-[#8E8E93] text-[10px] font-mono px-2 py-0.5 rounded-full border border-[#2D2D2E]">
                        {dept.active_tickets} active · {dept.resolved_tickets} resolved
                      </span>
                    </div>
                    {/* SLA Progress Bar */}
                    <div className="mt-2 flex items-center space-x-2">
                      <div className="flex-1 bg-[#2D2D2E] rounded-full h-1.5 overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            isLowSla ? 'bg-[#FF4B2B]' : isHighSla ? 'bg-[#2ECC71]' : 'bg-[#3B82F6]'
                          }`}
                          style={{ width: `${dept.sla_compliance}%` }}
                        />
                      </div>
                      <span className={`text-[10px] font-bold font-mono ${
                        isLowSla ? 'text-[#FF4B2B]' : isHighSla ? 'text-[#2ECC71]' : 'text-[#3B82F6]'
                      }`}>
                        SLA {dept.sla_compliance}%
                      </span>
                    </div>
                  </div>

                  {/* Rating Metrics & Speed */}
                  <div className="flex items-center space-x-6 md:border-l md:border-[#2D2D2E] md:pl-6 pt-2 md:pt-0">
                    <div className="text-left">
                      <span className="text-[9px] font-mono font-bold text-[#8E8E93] block uppercase">Response SLA</span>
                      <span className="text-xs font-mono font-medium text-white flex items-center">
                        <Clock size={11} className="mr-1 text-[#60A5FA]" />
                        Avg: {dept.avg_resolution_hours}h
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[9px] font-mono font-bold text-[#8E8E93] block uppercase">Dept. Index</span>
                      <span className={`text-sm font-display font-bold ${
                        dept.performance_score >= 90 ? 'text-[#2ECC71]' : 'text-slate-300'
                      }`}>
                        {dept.performance_score}/100
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
